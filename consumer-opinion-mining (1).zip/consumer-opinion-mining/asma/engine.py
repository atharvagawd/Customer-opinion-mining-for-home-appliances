"""ASMA engine: offline, lexicon + rule based opinion mining for appliance reviews.
Pipeline: clean -> tokenize -> normalize -> sentiment -> aspects -> opinions -> keywords -> aggregate.
Pure library: no backend/database imports. The services layer calls it."""
import re
from collections import Counter, defaultdict

ASPECTS = {
 "Performance": ["performance", "performs", "performed", "works", "working", "speed", "power", "suction"],
 "Cooling": ["cooling", "cools", "cooled", "freezer", "chilling", "cold"],
 "Washing Quality": ["washing", "wash", "washes", "cleans", "clothes", "stains", "rinse"],
 "Noise": ["noise", "noisy", "loud", "sound", "quiet", "silent"],
 "Design": ["design", "looks", "look", "beautiful", "sleek", "colour", "color", "style", "finish"],
 "Price": ["price", "cost", "expensive", "cheap", "value", "money", "overpriced", "affordable", "worth"],
 "Energy Consumption": ["electricity", "energy", "bill", "consumes", "consumption", "power consumption"],
 "Installation": ["installation", "install", "installed", "setup", "delivery"],
 "Customer Service": ["service", "support", "customer care", "staff", "helpline", "technician"],
 "Durability": ["durable", "durability", "broke", "broken", "lasted", "stopped working", "build quality", "flimsy"],
 "Features": ["feature", "features", "mode", "modes", "app", "smart", "wifi", "display", "timer", "remote"],
 "Maintenance": ["maintenance", "filter", "repair", "servicing", "spare"],
 "Vibration": ["vibration", "vibrates", "shaking", "wobble", "wobbles"],
}
_ASPECT_RE = {a: re.compile(r"\b(" + "|".join(sorted(map(re.escape, kws), key=len, reverse=True)) + r")\b")
              for a, kws in ASPECTS.items()}

POS = {"excellent": 2, "great": 1.5, "good": 1, "amazing": 2, "beautiful": 1.5, "awesome": 2, "love": 1.5,
       "loved": 1.5, "perfect": 2, "smooth": 1, "fast": 1, "quick": 1, "efficient": 1.5, "powerful": 1.5,
       "sleek": 1, "stylish": 1, "easy": 1, "helpful": 1.5, "quiet": 1.5, "silent": 1.5, "durable": 1.5,
       "reliable": 1.5, "affordable": 1, "best": 2, "fantastic": 2, "impressive": 1.5, "well": 1, "nice": 1,
       "superb": 2, "prompt": 1, "friendly": 1, "spacious": 1, "compact": 0.5, "worth": 1, "happy": 1.5,
       "satisfied": 1.5, "recommend": 1.5, "premium": 1, "responsive": 1}
NEG = {"poor": 1.5, "bad": 1.5, "terrible": 2, "worst": 2, "noisy": 1.5, "loud": 1.5, "slow": 1, "delay": 1.5,
       "delayed": 1.5, "weak": 1.5, "broke": 2, "broken": 2, "faulty": 2, "defective": 2, "useless": 2,
       "disappointing": 1.5, "disappointed": 1.5, "overpriced": 1.5, "expensive": 1, "rude": 2, "unhelpful": 1.5,
       "flimsy": 1.5, "leaks": 1.5, "leaking": 1.5, "failed": 2, "horrible": 2, "awful": 2, "vibrates": 1.5,
       "vibration": 1, "problem": 1, "issue": 1, "difficult": 1, "cumbersome": 1, "hot": 0.5, "unresponsive": 1.5,
       "complaint": 1, "regret": 2, "waste": 1.5, "wobbles": 1.5, "shaking": 1.2}
PHRASES = {"too much": -1.5, "a lot of noise": -2, "a lot of vibration": -2, "high electricity": -1.5,
           "high bill": -1.5, "not worth": -1.5, "waste of money": -2, "stopped working": -2,
           "no response": -1.5, "never showed": -2, "no noise": 1.5, "value for money": 1.5,
           "saves electricity": 1.5, "low noise": 1.5, "easy to use": 1.5, "easy to clean": 1.5}
INTENS = {"very": 1.5, "extremely": 1.8, "really": 1.3, "too": 1.5, "super": 1.5, "highly": 1.5, "so": 1.3}
NEGATORS = {"not", "never", "no", "hardly", "barely", "without"}
STOP = set("the a an and or but is are was were it its this that to of in on for with has have had i my we our "
           "very really just also be been so too at as by from me you they them than then there their will would "
           "can could should do does did not no makes looks consumes much feels get went".split())
CATEGORY_TERMS = {
 "Refrigerator": ["refrigerator", "fridge", "freezer", "compressor", "cooling", "defrost"],
 "Washing Machine": ["washing machine", "washer", "laundry", "clothes", "spin", "spinning", "detergent", "drum"],
 "Air Conditioner": ["air conditioner", "ac", "split ac", "room cooling", "tonnage", "remote", "inverter"],
 "Microwave Oven": ["microwave", "oven", "heating", "grill", "convection", "reheat", "turntable"],
 "Vacuum Cleaner": ["vacuum", "suction", "dust", "carpet", "cordless", "dustbin", "brush"],
}
CONTRAST = re.compile(r"\b(?:but|however|although|though|yet|whereas|while)\b|[.;!?]")
SPLIT = re.compile(r",|\band\b|\bplus\b")


# ---- 1-3. preprocessing -------------------------------------------------
def preprocess(text):
    """Clean, tokenize, normalize. Returns a dict so the UI can display each step."""
    cleaned = re.sub(r"<[^>]+>|https?://\S+", " ", text)
    cleaned = re.sub(r"\s+", " ", cleaned).strip()
    norm = cleaned.lower()
    norm = norm.replace("won't", "will not").replace("can't", "can not")
    norm = re.sub(r"n't\b", " not", norm)
    return {"cleaned": cleaned, "normalized": norm, "tokens": re.findall(r"[a-z]+", norm)}


# ---- 4. sentiment scoring ----------------------------------------------
def score_text(text):
    """Return (score, opinion_phrase). Handles phrases, negation, intensifiers."""
    toks = re.findall(r"[a-z]+", text)
    hits, i = [], 0
    while i < len(toks):
        hit = None
        for n in (4, 3, 2):
            ph = " ".join(toks[i:i + n])
            if ph in PHRASES:
                hit = (PHRASES[ph], i, i + n)
                break
        if not hit:
            w = toks[i]
            base = POS.get(w, 0) - NEG.get(w, 0)
            if not base and w.endswith("s"):
                base = POS.get(w[:-1], 0) - NEG.get(w[:-1], 0)
            if base:
                start = i
                if i > 0 and toks[i - 1] in INTENS:
                    base *= INTENS[toks[i - 1]]
                    start = i - 1
                for k in range(max(0, start - 3), start):
                    if toks[k] in NEGATORS:
                        base *= -0.8
                        start = k
                        break
                hit = (base, start, i + 1)
        if hit:
            hits.append(hit)
            i = hit[2]
        else:
            i += 1
    if not hits:
        return 0.0, ""
    best = max(hits, key=lambda h: abs(h[0]))
    return sum(h[0] for h in hits), " ".join(toks[best[1]:best[2]])


def label(score):
    return "Positive" if score >= 0.5 else "Negative" if score <= -0.5 else "Neutral"


# ---- 5-6. aspect + opinion extraction ----------------------------------
def detect_aspects(seg):
    return [(a, m.group(1)) for a, rx in _ASPECT_RE.items() if (m := rx.search(seg))]


def extract_opinions(norm):
    found = {}
    for clause in CONTRAST.split(norm):
        if not clause.strip():
            continue
        c_score, c_op = score_text(clause)
        for seg in SPLIT.split(clause):
            seg = seg.strip()
            for aspect, trig in detect_aspects(seg):
                sc, op = score_text(seg)
                if sc == 0:
                    sc, op = c_score, c_op
                op = op or seg
                cur = found.get(aspect)
                if cur is None or abs(sc) > abs(cur["score"]):
                    found[aspect] = {"aspect": aspect, "opinion": op, "sentiment": label(sc),
                                     "score": round(sc, 2), "trigger": trig}
    return list(found.values())


# ---- 7. keywords / classification --------------------------------------
def extract_keywords(tokens, opinions, k=6):
    kws = [o["trigger"] for o in opinions]
    freq = Counter(t for t in tokens if t not in STOP and len(t) > 2 and t not in POS and t not in NEG)
    kws += [w for w, _ in freq.most_common() if w not in kws]
    return kws[:k]


def classify_category(norm):
    scores = {c: sum(len(re.findall(r"\b" + re.escape(t) + r"\b", norm)) for t in terms)
              for c, terms in CATEGORY_TERMS.items()}
    best = max(scores, key=scores.get)
    return best if scores[best] else "Unknown"


# ---- full pipeline ------------------------------------------------------
def analyze_review(text, rating=None):
    pre = preprocess(text)
    ops = extract_opinions(pre["normalized"])
    total, _ = score_text(pre["normalized"])
    pos = any(o["sentiment"] == "Positive" for o in ops)
    neg = any(o["sentiment"] == "Negative" for o in ops)
    if pos and neg:
        overall = "Mixed"
    elif pos:
        overall = "Positive"
    elif neg:
        overall = "Negative"
    else:
        overall = label(total)
        if overall == "Neutral" and rating and rating != 3:
            overall = "Positive" if rating >= 4 else "Negative"
    return {"cleaned_text": pre["cleaned"], "tokens": pre["tokens"], "overall_sentiment": overall,
            "sentiment_score": round(total, 2), "opinions": ops,
            "keywords": extract_keywords(pre["tokens"], ops),
            "predicted_category": classify_category(pre["normalized"])}


# ---- aggregation / trends / summary ------------------------------------
def aggregate(analyses):
    """analyses: list of analyze_review() results -> {aspect: stats}"""
    agg = defaultdict(Counter)
    for a in analyses:
        for o in a["opinions"]:
            agg[o["aspect"]][o["sentiment"]] += 1
    res = {}
    for asp, c in agg.items():
        n = sum(c.values())
        res[asp] = {"mentions": n, "positive": c["Positive"], "negative": c["Negative"], "neutral": c["Neutral"],
                    "positive_pct": round(100 * c["Positive"] / n), "negative_pct": round(100 * c["Negative"] / n)}
    return res


def trending_issues(agg, min_mentions=3, min_negative_pct=40):
    rows = [(a, s["negative"], s["negative_pct"]) for a, s in agg.items()
            if s["mentions"] >= min_mentions and s["negative_pct"] >= min_negative_pct]
    return sorted(rows, key=lambda r: -r[1])


def summarize(agg, product="this product"):
    good = sorted((a for a, s in agg.items() if s["mentions"] >= 2 and s["positive_pct"] >= 60),
                  key=lambda a: -agg[a]["positive"])[:2]
    bad = sorted((a for a, s in agg.items() if s["mentions"] >= 2 and s["negative_pct"] >= 40),
                 key=lambda a: -agg[a]["negative"])[:2]
    g, b = " and ".join(x.lower() for x in good), " and ".join(x.lower() for x in bad)
    if g and b:
        return f"Most customers appreciate the {g} of {product}, while the most common complaints concern {b}."
    if g:
        return f"Customers are largely satisfied with {product}, praising its {g}."
    if b:
        return f"Customers mainly raise concerns about {product}, mainly {b}."
    return f"Opinions on {product} are limited or evenly split."

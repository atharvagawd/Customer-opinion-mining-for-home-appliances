# ASMA Implementation (asma/engine.py)
Offline, lexicon- and rule-based; deterministic and explainable.
1. **Cleaning/tokenising/normalising** – strips HTML/URLs, lowercases, expands negations (`isn't`→`is not`).
2. **Sentiment** – weighted positive/negative lexicon, multi-word phrases ("a lot of noise", "too much"), intensifiers (very, too, extremely) and negation within 3 tokens.
3. **Aspect extraction** – 13 aspects matched by keyword patterns on clause segments (split at but/however/while and at commas/“and”).
4. **Opinion extraction** – the strongest sentiment phrase in the segment ("very well", "a lot of noise"); segments without own sentiment inherit the clause sentiment.
5. **Overall label** – Mixed if both positive and negative aspects exist; else Positive/Negative; else lexicon score, with rating as tie-breaker → Neutral.
6. **Keywords** – aspect trigger words first, then frequent non-stop words. **Classification** – category term scoring.
7. **Aggregation / trending / summary** – per-aspect positive/negative % (`aggregate`), `trending_issues`, template-based `summarize`.
Limitations: sarcasm, spelling errors and unseen vocabulary are not handled; extend the lexicons to improve coverage.

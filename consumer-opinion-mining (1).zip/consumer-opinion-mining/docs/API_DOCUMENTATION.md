# REST API (all JSON; header `Authorization: Bearer <token>`)
| Method & path | Roles | Purpose |
|---|---|---|
| POST /api/auth/login, /api/auth/register | public | Login (returns token) / customer sign-up |
| GET /api/me | any | Current user |
| GET /api/products, /api/products/:id | any | List / details with aspects, summary, issues |
| POST/PUT/DELETE /api/products | admin | Product CRUD |
| GET /api/reviews (filters product_id, sentiment, category, q) | any (customers: own) | List reviews |
| POST /api/reviews | customer, admin | Submit review (status `received`) |
| POST /api/reviews/:id/analyze | any (own for customers) | Run ASMA, store results, detect issues |
| POST /api/analyze | any | Preview analysis without storing |
| PUT/DELETE /api/reviews/:id | admin | Edit (re-analyses) / delete |
| GET /api/dashboard | analyst, PM | Dashboard data |
| GET /api/analytics?product_id= or category= | analyst, PM | Aspect aggregates, trending issues, keywords |
| GET /api/compare?a=&b= | analyst, PM | Two-product comparison |
| GET /api/issues, /api/issues/:id/updates; PUT /api/issues/:id | analyst, PM (PUT: PM) | Issue workflow |
| GET /api/reports/:kind?format=csv | analyst, PM | product_opinion, sentiment, aspect, recurring, comparison |
| GET/POST/PUT/DELETE /api/users | admin | User management |
| GET /api/itpm, PUT /api/itpm/tasks/:id, POST /api/itpm/tests/run | PM | ITPM data, task updates, run tests |
Admin may call every endpoint.

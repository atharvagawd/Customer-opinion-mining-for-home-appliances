# Project Architecture
```
Frontend (frontend/: index.html, app.js, style.css; Chart.js)
   ↓ REST + signed bearer token
Flask API (backend/app.py) – auth, RBAC, CRUD, dashboard, reports, ITPM
   ↓
Enterprise services (backend/services.py) – persistence, issue detection
   ↓
ASMA/NLP engine (asma/engine.py) – pure library, no web/DB imports
   ↓
SQLite database (database/schema.sql, hometech.db)
```
- **ASMA** = intelligence/text analysis. **Enterprise Systems** = organisational data, roles, workflow, dashboard. **ITPM** = planning, development, testing (data in data/itpm.json, served by /api/itpm).
- Review workflow: Customer review → received → text processing → ASMA analysis → opinion extraction → DB storage → manager dashboard → issue detection → manager review → resolution/monitoring.
- Issues are created automatically when a product has ≥3 negative mentions of an aspect and ≥40% negativity.

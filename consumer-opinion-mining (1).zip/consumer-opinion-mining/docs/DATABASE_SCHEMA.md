# Database Schema (database/schema.sql)
| Table | Purpose | Key relations |
|---|---|---|
| users | Accounts and role (customer, analyst, product_manager, admin) | – |
| products | Product catalogue (name, brand, category, model, price, description) | – |
| reviews | Review text, rating, date, processing_status | user_id→users, product_id→products |
| review_analysis | Overall sentiment, score, keywords, predicted category | review_id→reviews (1:1) |
| aspects | Aspect dictionary (Noise, Cooling, …) | – |
| opinions | Aspect-level opinion phrase and sentiment | review_id→reviews, aspect_id→aspects |
| issues | Recurring complaint per product+aspect, status New/Under Review/In Progress/Resolved | product_id, aspect_id, assigned_to |
| issue_updates | Status-change history with notes | issue_id, user_id |
CHECK constraints enforce roles, categories, sentiments and statuses; deleting a product cascades to its reviews, analysis and issues. Seed: 4 staff + 8 customers, 10 products, 110 reviews (`backend/seed.py`).

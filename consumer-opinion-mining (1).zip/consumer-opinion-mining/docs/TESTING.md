# Testing
- **Unit tests (ASMA):** `python tests/test_asma.py` – washing-machine and refrigerator examples, negation, neutral reviews, aggregation and summaries.
- **System tests:** 11 cases (TC01–TC11: authentication, RBAC, sentiment, aspects, negation, neutral, classification, dashboard API, issue permissions) executed from the UI (ITPM → Testing → Run all tests); results are stored in `data/itpm.json`.
- **Manual acceptance:** follow the demonstration flow in README.md.
- **UI simulation (tests/ui_qc.js):** loads the real `frontend/app.js` in a simulated browser (jsdom) against the running server and drives all 4 roles through every page, filter, form and button (242 checks, also runs with the real bundled Chart.js). Optional: `cd tests && npm install jsdom@24 && node ui_qc.js` (start the server first; run `python backend/seed.py` afterwards to reset data).

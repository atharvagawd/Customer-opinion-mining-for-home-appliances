# ITPM Documentation
Live in the app under **IT Project Management** (data: `data/itpm.json`): project charter and scope, WBS (10 work packages), 10-week Gantt chart (3 Aug – 11 Oct 2026), 14 tasks with status/priority/dates/completion (editable by Product Manager), 5-member team with responsibilities, risk register (probability × impact = severity; 6 risks), and testing management (11 test cases executed live against the system).
Deployment: local Flask server (`python backend/app.py`). Maintenance: re-seed script, lexicon extension, MySQL migration (task blocked in the sample plan).

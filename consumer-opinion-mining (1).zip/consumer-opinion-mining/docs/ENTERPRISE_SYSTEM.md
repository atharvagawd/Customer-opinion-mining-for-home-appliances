# Enterprise System
**Roles/permissions:** Customer – view products, submit reviews, view own analysed reviews. Analyst – dashboard, review analysis, analytics, comparison, read-only issues and reports. Product Manager – analyst rights plus issue status changes, reports, ITPM. Administrator – everything plus product CRUD, review deletion, user management.
**Modules:** authentication (signed tokens, hashed passwords) · product management · review management · enterprise dashboard · recurring-issue workflow (New → Under Review → In Progress → Resolved, with history in `issue_updates`) · reports (product opinion, sentiment, aspect, recurring complaint, comparison; CSV download, print to PDF).
RBAC is enforced server-side by the `@auth(...)` decorator; the UI only hides menus.

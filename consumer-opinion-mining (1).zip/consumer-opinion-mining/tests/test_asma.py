import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from asma.engine import analyze_review, aggregate, summarize, trending_issues

def asp(r): return {o["aspect"]: o["sentiment"] for o in r["opinions"]}

def test_washing_noise():
    r = analyze_review("The washing machine cleans clothes very well but makes a lot of noise during spinning.")
    assert asp(r)["Washing Quality"] == "Positive" and asp(r)["Noise"] == "Negative"
    assert r["overall_sentiment"] == "Mixed" and r["predicted_category"] == "Washing Machine"

def test_fridge_example():
    r = analyze_review("The refrigerator has excellent cooling and looks beautiful, but it consumes too much electricity and the compressor is noisy.")
    assert asp(r) == {"Cooling": "Positive", "Design": "Positive", "Energy Consumption": "Negative", "Noise": "Negative"}
    assert r["overall_sentiment"] == "Mixed"

def test_neutral_and_negation():
    assert analyze_review("It is a microwave oven. Arrived on Monday.", 3)["overall_sentiment"] == "Neutral"
    assert asp(analyze_review("The vacuum is not noisy at all."))["Noise"] == "Positive"

def test_aggregate_summary():
    rs = [analyze_review(t) for t in ["Great design and powerful suction.", "Loved the design, quiet motor.",
          "Terrible service, very rude staff.", "Poor customer service and delayed installation."]]
    ag = aggregate(rs)
    assert ag["Design"]["positive_pct"] == 100
    assert "Customer Service" in [t[0] for t in trending_issues(ag, 2)]
    assert "design" in summarize(ag, "the vacuum")

if __name__ == "__main__":
    for n, f in list(globals().items()):
        if n.startswith("test_"):
            f(); print("PASS", n)

const {JSDOM,VirtualConsole}=require('jsdom'); const fs=require('fs');
const BASE='http://localhost:5000', SRC=fs.readFileSync(__dirname+'/../frontend/app.js','utf8');
let pass=0,fail=0; const errs=[];
const ok=(c,m)=>{ if(c){pass++;} else {fail++; console.log('  FAIL:',m);} };
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function newApp(){
  const vc=new VirtualConsole(); vc.on('jsdomError',e=>errs.push('jsdomError '+e.message.slice(0,150))); vc.on('error',e=>errs.push('console.error '+String(e).slice(0,150)));
  const dom=new JSDOM('<!doctype html><body><div id="app"></div></body>',{url:BASE+'/',runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:vc});
  const w=dom.window; w.charts=0; w.alerts=[];
  if(process.env.REAL){ w.ResizeObserver=class{observe(){}unobserve(){}disconnect(){}}; w.devicePixelRatio=1;
  const ctx=new Proxy({canvas:null},{get:(t,k)=>k==='measureText'?()=>({width:10}):k in t?t[k]:()=>{}, set:()=>true});
  w.HTMLCanvasElement.prototype.getContext=function(){ return new Proxy({canvas:this},{get:(t,k)=>k==='canvas'?this:k==='measureText'?()=>({width:10}):k==='createLinearGradient'||k==='createPattern'?()=>({addColorStop(){}}):()=>{}, set:()=>true}); };
  w.eval(fs.readFileSync(__dirname+'/../frontend/vendor/chart.umd.js','utf8')); const RC=w.Chart; w.Chart=class extends RC{constructor(c,cfg){ super(c,cfg); w.charts++; }};
} else w.Chart=class{constructor(c,cfg){ if(!c||!c.getContext&&!c.tagName) throw new Error('chart canvas missing'); if(!cfg.data||!cfg.data.datasets) throw new Error('bad chart cfg'); w.charts++;} destroy(){}};
  w.fetch=(u,o)=>fetch(new URL(u,BASE),o); w.scrollTo=()=>{}; w.alert=m=>w.alerts.push(m); w.confirm=()=>true; w.prompt=()=>'qc note';
  w.URL.createObjectURL=()=>'blob:x'; { const oc=w.HTMLAnchorElement.prototype.click; w.HTMLAnchorElement.prototype.click=function(){ if(this.download){ w.downloaded=(w.downloaded||[]).concat(this.download); } else oc.call(this); }; }
  w.addEventListener('error',e=>errs.push('window.error '+e.message));
  w.eval(SRC); await sleep(50); return w;
}
const $=(w,s)=>w.document.querySelector(s), $$=(w,s)=>[...w.document.querySelectorAll(s)];
async function settle(w){ for(let i=0;i<60;i++){ await sleep(40); const m=$(w,'#main'); if(m&&!m.textContent.includes('Loading…')) { await sleep(60); return; } } }
async function go(w,h){ w.charts=0; w.location.hash=h; await sleep(30); await settle(w); }
const mainErr=w=>{ const m=$(w,'#main'); return m && /color:#dc2626/.test(m.innerHTML) ? m.textContent.slice(0,100) : null; };
async function login(w,email,pw){ $(w,'#em').value=email; $(w,'#pw').value=pw; $(w,'#go').click(); for(let i=0;i<40&&!$(w,'.side');i++) await sleep(50); await settle(w); }
const click=async(w,el,ms=250)=>{ el.click(); await sleep(ms); };
const set=(el,v)=>{ el.value=v; };
const fire=(w,el,t='change')=>el.dispatchEvent(new w.Event(t,{bubbles:true}));
const USERS={customer:['customer@hometech.com','Customer@123'],analyst:['analyst@hometech.com','Analyst@123'],product_manager:['manager@hometech.com','Manager@123'],admin:['admin@hometech.com','Admin@123']};
const MENU={customer:['products','submit','reviews','integration'],analyst:['dashboard','products','reviews','analytics','compare','issues','reports','integration'],product_manager:['dashboard','products','reviews','analytics','compare','issues','reports','itpm','integration'],admin:['dashboard','products','submit','reviews','analytics','compare','issues','reports','itpm','integration','admin','users']};
const ALL=['dashboard','products','submit','reviews','analytics','compare','issues','reports','itpm','integration','admin','users'];
const TXT={dashboard:'Total Reviews',products:'Brand',submit:'Submit a customer review',reviews:'Review',analytics:'Aspect',compare:'Overview',issues:'Recurring Issues',reports:'Choose a report',itpm:'Project Charter',integration:'One application',admin:'Add / Edit Product',users:'Users & Roles'};

(async()=>{
 // ---- 3/4: login, menus, restrictions, logout for 4 roles; all pages
 for(const role of Object.keys(USERS)){
  console.log('== role',role); const w=await newApp();
  ok($(w,'.login'),'login view'); 
  $(w,'#em').value='x@x.com'; $(w,'#pw').value='bad'; $(w,'#go').click(); await sleep(300); ok($(w,'#le').textContent.includes('Invalid'),'bad login message');
  await login(w,...USERS[role]); ok($(w,'.side'),'shell after login');
  const menu=$$(w,'.side a').map(a=>a.dataset.m); ok(JSON.stringify(menu)===JSON.stringify(MENU[role]),'menu '+menu);
  ok($(w,'.who').textContent.includes(USERS[role][0].split('@')[0]==='manager'?'Meera':$(w,'.who').textContent),'who label');
  for(const p of MENU[role]){ await go(w,'#/'+p); const e=mainErr(w); ok(!e,`${role}/${p} error:${e}`); ok($(w,'#main').textContent.includes(TXT[p]),`${role}/${p} content "${TXT[p]}"`); ok($(w,'.side a.on')?.dataset.m===p,`${role}/${p} active nav`); }
  if(['dashboard','analytics','compare'].some(p=>MENU[role].includes(p))) {}
  for(const p of ALL.filter(p=>!MENU[role].includes(p))){ await go(w,'#/'+p); ok($(w,'.side a.on')?.dataset.m===MENU[role][0],`${role} blocked from ${p} -> fell back to ${MENU[role][0]}`); }
  // API-level restrictions
  const tok=w.localStorage.tok; const H={Authorization:'Bearer '+tok,'Content-Type':'application/json'};
  const st=async(m,p,b)=>(await fetch(BASE+'/api'+p,{method:m,headers:H,body:b?JSON.stringify(b):undefined})).status;
  const exp={customer:{dash:403,issues:403,users:403,itpm:403,reports:403},analyst:{dash:200,issues:200,users:403,itpm:403,reports:200},product_manager:{dash:200,issues:200,users:403,itpm:200,reports:200},admin:{dash:200,issues:200,users:200,itpm:200,reports:200}}[role];
  ok(await st('GET','/dashboard')===exp.dash,'api dashboard'); ok(await st('GET','/issues')===exp.issues,'api issues'); ok(await st('GET','/users')===exp.users,'api users');
  ok(await st('GET','/itpm')===exp.itpm,'api itpm'); ok(await st('GET','/reports/sentiment')===exp.reports,'api reports');
  { const r=await fetch(BASE+'/api/products',{method:'POST',headers:H,body:JSON.stringify({name:'x',brand:'y',category:'Refrigerator'})}); ok(r.status===(role==='admin'?201:403),'api product create '+role); if(r.status===201){ const id=(await r.json()).id; await fetch(BASE+'/api/products/'+id,{method:'DELETE',headers:H}); } }
  // logout
  await click(w,$$(w,'button').find(b=>b.textContent==='Logout')); ok($(w,'.login')&&!w.localStorage.tok,'logout -> login view');
 }
 // cleanup admin-created product
 // ---- 5 customer flow
 console.log('== customer flow'); let w=await newApp(); await login(w,...USERS.customer);
 await go(w,'#/products'); ok($$(w,'#plist tbody tr').length===10,'10 products listed');
 set($(w,'#pq'),'refrigerator'); fire(w,$(w,'#pq'),'input'); ok($$(w,'#plist tbody tr').length===2,'search refrigerator -> '+$$(w,'#plist tbody tr').length); 
 set($(w,'#pq'),''); set($(w,'#pc'),'Vacuum Cleaner'); fire(w,$(w,'#pc')); ok($$(w,'#plist tbody tr').length===2,'category filter vacuum');
 await click(w,$(w,'#plist a'),300); await settle(w); await sleep(200); ok($(w,'#main').textContent.includes('Opinion summary')&&w.charts===2,'product details + 2 charts '+w.charts+' '+w.location.hash+' '+$(w,'#main').textContent.slice(0,120));
 await go(w,'#/submit'); const sel=$(w,'#sp'); set(sel,$$(w,'#sp option').find(o=>o.textContent==='LG Refrigerator').value); fire(w,sel); ok($(w,'#rt').value.includes('excellent cooling'),'sample text prefilled');
 set($(w,'#rr'),'3'); await click(w,$(w,'#sub'),400); ok($(w,'#out').textContent.includes('received'),'received status shown'); 
 await click(w,$(w,'#an'),500); const out=$(w,'#out').textContent; ok(/Mixed/.test(out)&&/Cooling/.test(out)&&/Noise/.test(out)&&/Energy Consumption/.test(out)&&/Stored in DB/.test(out),'analysis result shown: '+out.slice(0,80));
 set($(w,'#rt'),'short'); await click(w,$(w,'#sub'),300); ok($(w,'#out').textContent.includes('at least 10'),'validation message');
 await go(w,'#/reviews'); const rows=$$(w,'#rl tbody tr'); ok(rows.length>=1&&rows[0].textContent.includes('LG Refrigerator'),'my review listed (own reviews only: '+rows.length+')'); ok(!$$(w,'#rl button').some(b=>b.textContent==='Delete'),'customer cannot delete');
 await click(w,$$(w,'#rl button').find(b=>b.textContent==='View'),300); ok($(w,'#detail').textContent.includes('Keywords')&&$(w,'#detail').textContent.includes('Cooling'),'view result in review analysis');
 // ---- 6 analyst flow
 console.log('== analyst flow'); w=await newApp(); await login(w,...USERS.analyst);
 await go(w,'#/dashboard'); ok(w.charts===4,'dashboard 4 charts: '+w.charts); ok($$(w,'.cards .stat').length===6,'6 stat cards'); ok($(w,'#main').textContent.includes('Issues Requiring Attention')&&$(w,'#main').textContent.includes('Top Complaints')&&$(w,'#main').textContent.includes('Recent Reviews'),'dashboard sections');
 await go(w,'#/reviews'); const n0=$$(w,'#rl tbody tr').length; ok(n0>50,'reviews listed '+n0);
 set($(w,'#fs'),'Mixed'); fire(w,$(w,'#fs')); await sleep(400); const n1=$$(w,'#rl tbody tr').length; ok(n1>0&&n1<n0&&$$(w,'#rl tbody tr').every(r=>r.textContent.includes('Mixed')),'sentiment filter '+n1);
 set($(w,'#fs'),''); set($(w,'#fq'),'noisy'); fire(w,$(w,'#fq'),'input'); await sleep(400); ok($$(w,'#rl tbody tr').length>0&&$$(w,'#rl tbody tr').every(r=>/noisy/i.test(r.textContent)),'search noisy');
 set($(w,'#fq'),''); set($(w,'#fp'),'3'); fire(w,$(w,'#fp')); await sleep(400); ok($$(w,'#rl tbody tr').every(r=>r.textContent.includes('LG Washing Machine')),'product filter');
 await click(w,$$(w,'#rl button').find(b=>b.textContent==='View'),300); ok($(w,'#detail').textContent.includes('Normalization'),'review detail pipeline');
 await go(w,'#/analytics'); await sleep(300); ok(w.charts===2&&$(w,'#res').textContent.includes('Trending Issues'),'analytics all');
 set($(w,'#af'),'c:Washing Machine'); fire(w,$(w,'#af')); await sleep(400); ok($(w,'#res').textContent.includes('Aspect Detail')&&w.charts>=2,'analytics category filter');
 await go(w,'#/issues'); ok($$(w,'#main select').length===0&&$(w,'#main').textContent.includes('read-only'),'analyst issues read-only '+$$(w,'#main select').length+' '+$(w,'#main').textContent.slice(0,200)+' hash='+w.location.hash); await click(w,$$(w,'button').find(b=>b.textContent==='History'),300); ok($(w,'#ih').textContent.includes('Status history'),'issue history');
 await go(w,'#/compare'); await sleep(300); ok(w.charts===3&&$(w,'#cmp').textContent.includes('Most common complaints'),'compare default charts'); set($(w,'#cb'),'1'); set($(w,'#ca'),'2'); fire(w,$(w,'#ca')); await sleep(400); ok($(w,'#cmp').textContent.includes('Samsung Refrigerator'),'compare changed');
 set($(w,'#cb'),'2'); fire(w,$(w,'#cb')); await sleep(300); // same product allowed
 // ---- 7 PM flow
 console.log('== product manager flow'); w=await newApp(); await login(w,...USERS.product_manager);
 await go(w,'#/issues'); const sels=$$(w,'#main select'); ok(sels.length>=5,'issue status selects '+sels.length);
 const before=$$(w,'#main tbody tr')[0].textContent; const s0=sels[0]; const id0=s0.parentElement.parentElement.firstChild.textContent; set(s0,'In Progress'); fire(w,s0); await sleep(700);
 const row0=$$(w,'#main tbody tr').find(r=>r.firstChild.textContent===id0); ok(/In Progress/.test(row0.textContent)&&row0.querySelector('select').value==='In Progress','status changed to In Progress');
 await click(w,[...row0.querySelectorAll('button')].find(b=>b.textContent==='History'),300); ok($(w,'#ih').textContent.includes('qc note'),'history has note');
 set(row0.querySelector('select'),'Under Review'); fire(w,row0.querySelector('select')); await sleep(600); ok($$(w,'#main tbody tr').some(r=>r.firstChild.textContent===id0&&/Under Review/.test(r.textContent)),'status Under Review');
 await go(w,'#/reports'); for(const k of ['Product Opinion','Customer Sentiment','Aspect Analysis','Recurring Complaint','Product Comparison']){ await click(w,$$(w,'.bar button').find(b=>b.textContent===k),400); ok($(w,'#rep table')&&$$(w,'#rep tbody tr').length>0,'report '+k); }
 await click(w,$$(w,'#rep button').find(b=>b.textContent==='Download CSV'),400); ok((w.downloaded||[]).includes('comparison_report.csv'),'csv download triggered');
 await go(w,'#/itpm'); const tabs=$$(w,'#itb button').map(b=>b.textContent); ok(tabs.join()==='Charter,WBS,Gantt,Tasks,Team,Risks,Testing','tabs '+tabs);
 const want={Charter:['Problem statement','In scope','Out of scope','Stakeholders','Deliverables'],WBS:['Work Breakdown Structure','Requirement Analysis','Database'],Gantt:['W10','Requirements','Documentation'],Tasks:['Task Management','Blocked','Completion'],Team:['Project Manager','Frontend Developer','NLP/ASMA Developer','Database/Enterprise Developer'],Risks:['Probability','Poor-quality review data','Insufficient dataset'],Testing:['Test Case','Passed','Run all tests']};
 for(const t of tabs){ await click(w,$$(w,'#itb button').find(b=>b.textContent===t),100); const tx=$(w,'#itc').textContent; ok(want[t].every(s=>tx.includes(s)),'ITPM '+t+' missing:'+want[t].filter(s=>!tx.includes(s))); }
 await click(w,$$(w,'#itb button').find(b=>b.textContent==='Gantt'),100); ok($$(w,'.gt i').length===10,'10 gantt bars');
 await click(w,$$(w,'#itb button').find(b=>b.textContent==='Tasks'),100); const ts=$$(w,'#itc select')[0]; set(ts,'Blocked'); fire(w,ts); await sleep(400); ok($$(w,'#itc select')[0].value==='Blocked','task status update'); set($$(w,'#itc select')[0],'Completed'); fire(w,$$(w,'#itc select')[0]); await sleep(300);
 const pn=$$(w,'#itc input[type=number]')[13]; set(pn,'10'); fire(w,pn); await sleep(300); ok($$(w,'#itc input[type=number]')[13].value==='10','task % updated'); set($$(w,'#itc input[type=number]')[13],'0'); fire(w,$$(w,'#itc input[type=number]')[13]); await sleep(300);
 await click(w,$$(w,'#itb button').find(b=>b.textContent==='Testing'),100); await click(w,$$(w,'#itc button').find(b=>b.textContent==='Run all tests'),1500); ok($(w,'#itc').textContent.includes('11/11 passed'),'tests 11/11: '+$(w,'#itc h3').textContent);
 await go(w,'#/integration'); const it=$(w,'#main').textContent; ok(/ASMA/.test(it)&&/Enterprise Systems/.test(it)&&/IT Project Management/.test(it)&&$$(w,'.map a').length>=20,'integration page: '+$$(w,'.map a').length+' links');
 for(const a of $$(w,'.map a')){ const h=a.getAttribute('href'); ok(MENU.product_manager.includes(h.slice(2))||h==='#/admin'||h==='#/users',`integration link ${h} visible to PM?`); }
 // ---- 8 admin flow
 console.log('== admin flow'); w=await newApp(); await login(w,...USERS.admin);
 await go(w,'#/admin'); const np=$$(w,'#main tbody tr').length; set($(w,'#pn'),'QC Test Fridge'); set($(w,'#pb'),'QC'); set($(w,'#pcat'),'Refrigerator'); set($(w,'#pm'),'Q1'); set($(w,'#ppr'),'12345'); set($(w,'#pd'),'qc'); await click(w,$$(w,'button').find(b=>b.textContent==='Save product'),700); await settle(w);
 ok($$(w,'#main tbody tr').length===np+1&&$(w,'#main').textContent.includes('QC Test Fridge'),'product added');
 const row=$$(w,'#main tbody tr').find(r=>r.textContent.includes('QC Test Fridge')); await click(w,[...row.querySelectorAll('button')].find(b=>b.textContent==='Edit'),50); ok($(w,'#pn').value==='QC Test Fridge','edit loads form'); set($(w,'#pn'),'QC Test Fridge 2'); await click(w,$$(w,'button').find(b=>b.textContent==='Save product'),700); await settle(w); ok($(w,'#main').textContent.includes('QC Test Fridge 2'),'product edited');
 set($(w,'#pn'),''); await click(w,$$(w,'button').find(b=>b.textContent==='Save product'),400); 
 const row2=$$(w,'#main tbody tr').find(r=>r.textContent.includes('QC Test Fridge 2')); await click(w,[...row2.querySelectorAll('button')].find(b=>b.textContent==='Delete'),700); await settle(w); ok(!$(w,'#main').textContent.includes('QC Test Fridge'),'product deleted');
 await go(w,'#/users'); const nu=$$(w,'#main tbody tr').length; set($(w,'#un'),'QC User'); set($(w,'#ue'),'qc@mail.com'); set($(w,'#up'),'Pass@123'); set($(w,'#ur'),'analyst'); await click(w,$$(w,'button').find(b=>b.textContent==='Create user'),700); await settle(w); ok($$(w,'#main tbody tr').length===nu+1,'user created');
 let ur=$$(w,'#main tbody tr').find(r=>r.textContent.includes('qc@mail.com')); const rs=ur.querySelector('select'); set(rs,'product_manager'); fire(w,rs); await sleep(700); await settle(w); ur=$$(w,'#main tbody tr').find(r=>r.textContent.includes('qc@mail.com')); ok(ur.querySelector('select').value==='product_manager','role changed');
 const w2=await newApp(); await login(w2,'qc@mail.com','Pass@123'); ok($$(w2,'.side a').length===9,'new PM user can login with PM menu'); 
 await click(w,[...ur.querySelectorAll('button')].find(b=>b.textContent==='Delete'),700); await settle(w); ok(!$(w,'#main').textContent.includes('qc@mail.com'),'user deleted');
 ok(![...$$(w,'#main tbody tr')].find(r=>r.textContent.includes('Admin User')).querySelector('button'),'admin cannot delete self');
 await go(w,'#/reviews'); const dr=$$(w,'#rl button').find(b=>b.textContent==='Delete'); ok(!!dr,'admin delete review button');
 await go(w,'#/product/3'); ok($(w,'#main').textContent.includes('LG Washing Machine')&&w.charts===2,'product detail page 13');
 console.log('\nPASS',pass,'FAIL',fail); console.log('Runtime errors:',errs.length?errs:'none'); process.exit(0);
})().catch(e=>{console.log('HARNESS CRASH',e);process.exit(1)});

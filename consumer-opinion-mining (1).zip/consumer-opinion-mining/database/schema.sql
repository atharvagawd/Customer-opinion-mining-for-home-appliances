-- HomeTech Opinion Mining schema (SQLite syntax; for MySQL swap AUTOINCREMENT->AUTO_INCREMENT)
PRAGMA foreign_keys = ON;
CREATE TABLE users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('customer','analyst','product_manager','admin')),
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE products (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL, brand TEXT NOT NULL,
  category TEXT NOT NULL CHECK (category IN ('Refrigerator','Washing Machine','Air Conditioner','Microwave Oven','Vacuum Cleaner')),
  model TEXT, price REAL, description TEXT
);
CREATE TABLE reviews (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  review_text TEXT NOT NULL,
  rating INTEGER CHECK (rating BETWEEN 1 AND 5),
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  processing_status TEXT DEFAULT 'received' CHECK (processing_status IN ('received','processing','analyzed','failed'))
);
CREATE TABLE review_analysis (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  review_id INTEGER NOT NULL UNIQUE REFERENCES reviews(id) ON DELETE CASCADE,
  overall_sentiment TEXT NOT NULL CHECK (overall_sentiment IN ('Positive','Negative','Neutral','Mixed')),
  sentiment_score REAL, keywords TEXT, predicted_category TEXT,
  cleaned_text TEXT, analyzed_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE aspects (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE
);
CREATE TABLE opinions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  review_id INTEGER NOT NULL REFERENCES reviews(id) ON DELETE CASCADE,
  aspect_id INTEGER NOT NULL REFERENCES aspects(id),
  opinion_text TEXT, sentiment TEXT NOT NULL CHECK (sentiment IN ('Positive','Negative','Neutral')),
  score REAL
);
CREATE TABLE issues (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  aspect_id INTEGER NOT NULL REFERENCES aspects(id),
  mentions INTEGER DEFAULT 0, negative_pct REAL DEFAULT 0,
  status TEXT DEFAULT 'New' CHECK (status IN ('New','Under Review','In Progress','Resolved')),
  assigned_to INTEGER REFERENCES users(id),
  created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
  UNIQUE (product_id, aspect_id)
);
CREATE TABLE issue_updates (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  issue_id INTEGER NOT NULL REFERENCES issues(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id),
  old_status TEXT, new_status TEXT NOT NULL, note TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_reviews_product ON reviews(product_id);
CREATE INDEX idx_opinions_review ON opinions(review_id);
CREATE INDEX idx_opinions_aspect ON opinions(aspect_id);

const COL = {Positive:'#16a34a',Negative:'#dc2626',Neutral:'#64748b',Mixed:'#d97706'}, CATS=['Refrigerator','Washing Machine','Air Conditioner','Microwave Oven','Vacuum Cleaner'];
const T = {tok:localStorage.tok, user:JSON.parse(localStorage.user||'null')};
const esc = s => String(s??'').replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const bd = t => `<span class="bd ${String(t).toLowerCase().replace(/\s+/g,'-')}">${esc(t)}</span>`;
const tbl = (cols, rows) => `<div class="tw"><table><thead><tr>${cols.map(c=>`<th>${c}</th>`).join('')}</tr></thead><tbody>${rows.map(r=>`<tr>${r.map(c=>`<td>${c}</td>`).join('')}</tr>`).join('')||`<tr><td colspan="${cols.length}" class="mu">No data</td></tr>`}</tbody></table></div>`;
const stat = (t,v) => `<div class="card stat"><div class="mu">${t}</div><div class="big">${v}</div></div>`;
const panel = (t,b,x='') => `<div class="card"><h3>${t}<span>${x}</span></h3>${b}</div>`;
const cv = (id,h=260) => `<div style="height:${h}px"><canvas id="${id}"></canvas></div>`;
const aspBd = s => (s||'').split('|').filter(Boolean).map(x => { const [a,t]=x.split(':'); return `<span class="bd ${t.toLowerCase()}">${esc(a)}</span>`; }).join('');
const fmt = d => (d||'').slice(0,10);
let CH = {};
function chart(id,cfg){ CH[id]?.destroy(); cfg.options={responsive:true,maintainAspectRatio:false,...(cfg.options||{})}; CH[id]=new Chart(document.getElementById(id),cfg); }
const sentCols = o => Object.keys(o).map(k=>COL[k]);

async function api(p,o={}){
  const r = await fetch('/api'+p,{method:o.method||'GET',headers:{'Content-Type':'application/json',Authorization:'Bearer '+T.tok},body:o.body?JSON.stringify(o.body):undefined});
  if(r.status===401 && p!=='/auth/login'){ logout(); throw new Error('Session expired'); }
  const d = await r.json().catch(()=>({})); if(!r.ok) throw new Error(d.error||r.statusText); return d;
}
async function download(path,name){
  const r = await fetch('/api'+path,{headers:{Authorization:'Bearer '+T.tok}}); if(!r.ok) return alert('Download failed');
  const a=document.createElement('a'); a.href=URL.createObjectURL(await r.blob()); a.download=name; a.click();
}
function logout(){ localStorage.clear(); T.tok=null; T.user=null; location.hash=''; boot(); }

const MENU = {
  customer:['products','submit','reviews','integration'],
  analyst:['dashboard','products','reviews','analytics','compare','issues','reports','integration'],
  product_manager:['dashboard','products','reviews','analytics','compare','issues','reports','itpm','integration'],
  admin:['dashboard','products','submit','reviews','analytics','compare','issues','reports','itpm','integration','admin','users']};
const TITLE = {dashboard:'Enterprise Dashboard',products:'Products',product:'Product Details',submit:'Submit Review',reviews:'Review Analysis',analytics:'Opinion Analytics',compare:'Product Comparison',issues:'Issue Management',reports:'Reports',itpm:'IT Project Management',integration:'Subject Integration',admin:'Admin Panel – Products',users:'User Management'};
const ROLE = {customer:'Customer',analyst:'Analyst',product_manager:'Product Manager',admin:'Administrator'};

function boot(){
  if(!T.tok) return loginView();
  $app.innerHTML = `<div class="shell"><nav class="side"><div class="logo">HomeTech Appliances<small>Customer Opinion Mining</small></div>${MENU[T.user.role].map(m=>`<a href="#/${m}" data-m="${m}">${TITLE[m].replace(' – Products','')}</a>`).join('')}</nav>
  <div class="main"><div class="top"><h2 id="title"></h2><div class="who"><span>${esc(T.user.name)} ${bd(ROLE[T.user.role])}</span><button class="sec" onclick="logout()">Logout</button></div></div><div id="main"></div></div></div>`;
  route();
}
const $app = document.getElementById('app');
function loginView(){
  const demo = [['Customer','customer@hometech.com','Customer@123'],['Analyst','analyst@hometech.com','Analyst@123'],['Product Manager','manager@hometech.com','Manager@123'],['Admin','admin@hometech.com','Admin@123']];
  $app.innerHTML = `<div class="login"><h1>HomeTech Opinion Mining</h1><p class="mu">Sign in to continue</p><input id="em" placeholder="Email"><input id="pw" type="password" placeholder="Password"><button style="width:100%" id="go">Sign in</button><p id="le" style="color:#dc2626"></p>
  <div class="mu">Demo accounts (click to fill)</div><div class="chips">${demo.map(d=>`<button class="sec" data-e="${d[1]}" data-p="${d[2]}">${d[0]}</button>`).join('')}</div></div>`;
  document.querySelectorAll('.chips button').forEach(b=>b.onclick=()=>{em.value=b.dataset.e;pw.value=b.dataset.p});
  const go = async()=>{ try{ const d=await api('/auth/login',{method:'POST',body:{email:em.value,password:pw.value}}); T.tok=localStorage.tok=d.token; T.user=d.user; localStorage.user=JSON.stringify(d.user); location.hash=''; boot(); }catch(e){ le.textContent=e.message; } };
  document.getElementById('go').onclick=go; pw.onkeydown=e=>e.key==='Enter'&&go();
}
async function route(){
  if(!T.tok) return;
  const [n,arg] = (location.hash.slice(2)||'').split('/'); const m=MENU[T.user.role];
  const page = n==='product' ? 'product' : m.includes(n) ? n : m[0];
  document.querySelectorAll('.side a').forEach(a=>a.classList.toggle('on',a.dataset.m===(page==='product'?'products':page)));
  document.getElementById('title').textContent = TITLE[page]; const el=document.getElementById('main'); el.innerHTML='<p class="mu">Loading…</p>';
  try{ let r = await PAGES[page](arg); if(Array.isArray(r)){ el.innerHTML=r[0]; r[1]&&r[1](); } else el.innerHTML=r; }catch(e){ el.innerHTML=`<div class="card" style="color:#dc2626">${esc(e.message)}</div>`; }
}
window.onhashchange = route;

/* ---------- shared analysis view ---------- */
function analysisView(r){
  return `<div class="pipe">${['Raw Review','Text Cleaning','Tokenization','Normalization','Sentiment','Aspects','Opinions','Keywords','Stored in DB'].map(s=>`<span>${s}</span>`).join('')}</div>
  <div class="g2"><div><p><b>Overall sentiment:</b> ${bd(r.sentiment||r.overall_sentiment)} <span class="mu">score ${r.sentiment_score}</span> &nbsp; <b>Category:</b> ${bd(r.predicted_category)}</p>
  <p class="mu">Cleaned text</p><p>${esc(r.cleaned_text)}</p><p class="mu">Tokens (${(r.tokens||[]).length})</p><p>${(r.tokens||[]).map(t=>`<span class="bd">${esc(t)}</span>`).join('')}</p>
  <p class="mu">Keywords</p><p>${(r.keywords||[]).map(k=>`<span class="bd new">${esc(k)}</span>`).join('')}</p></div>
  <div>${tbl(['Aspect','Opinion','Sentiment'],(r.opinions||[]).map(o=>[`<b>${esc(o.aspect)}</b>`,esc(o.opinion),bd(o.sentiment)]))}</div></div>`;
}

const PAGES = {
 async dashboard(){
  const d = await api('/dashboard'), s=d.sentiment, asp=d.aspects, neg=[...asp].filter(a=>a.mentions>=3).sort((a,b)=>b.negative_pct-a.negative_pct).slice(0,5), pos=[...asp].filter(a=>a.mentions>=3).sort((a,b)=>b.positive_pct-a.positive_pct).slice(0,5);
  const html = `<div class="cards">${stat('Total Products',d.products)}${stat('Total Reviews',d.reviews)}${['Positive','Negative','Neutral','Mixed'].map(k=>stat(k+' Reviews',s[k])).join('')}</div>
  <div class="g2">${panel('Sentiment Distribution',cv('c1'))}${panel('Review Trend (weekly)',cv('c2'))}</div>
  <div class="g2">${panel('Most Discussed Aspects',cv('c3'))}${panel('Product Comparison – % Positive Reviews',cv('c4'))}</div>
  <div class="g2">${panel('Most Negative Aspects',tbl(['Aspect','Negative %','Mentions'],neg.map(a=>[a.aspect,bd(a.negative_pct+'%').replace('bd','bd negative'),a.mentions])))}${panel('Most Positive Aspects',tbl(['Aspect','Positive %','Mentions'],pos.map(a=>[a.aspect,bd(a.positive_pct+'%').replace('bd','bd positive'),a.mentions])))}</div>
  ${panel('Top Complaints',tbl(['Product','Aspect','Complaint mentions','Negative %','Status'],d.top_complaints.map(i=>[i.product,i.aspect,i.mentions,i.negative_pct+'%',bd(i.status)])))}
  ${panel('Issues Requiring Attention',tbl(['Product','Aspect','Mentions','Status'],d.attention.map(i=>[i.product,i.aspect,i.mentions,bd(i.status)])),'<a href="#/issues">Manage →</a>')}
  ${panel('Recent Reviews',tbl(['Date','Product','Review','Sentiment','Aspects'],d.recent.map(r=>[fmt(r.created_at),esc(r.product),esc(r.review_text),bd(r.sentiment),aspBd(r.aspects)])))}`;
  return [html,()=>{
   chart('c1',{type:'doughnut',data:{labels:Object.keys(s),datasets:[{data:Object.values(s),backgroundColor:sentCols(s)}]}});
   chart('c2',{type:'line',data:{labels:d.trend.map(t=>t.week),datasets:['Positive','Negative','Neutral','Mixed'].map(k=>({label:k,data:d.trend.map(t=>t[k]),borderColor:COL[k],tension:.3}))}});
   chart('c3',{type:'bar',data:{labels:asp.slice(0,8).map(a=>a.aspect),datasets:[{label:'Mentions',data:asp.slice(0,8).map(a=>a.mentions),backgroundColor:'#2563eb'}]},options:{indexAxis:'y'}});
   chart('c4',{type:'bar',data:{labels:d.product_compare.map(p=>p.name),datasets:[{label:'% Positive',data:d.product_compare.map(p=>p.pos_pct),backgroundColor:'#16a34a'}]},options:{scales:{y:{max:100}}}});}];
 },
 async products(){
  const ps = await api('/products');
  const f = () => { const q=pq.value.toLowerCase(), c=pc.value; document.getElementById('plist').innerHTML=tbl(['Product','Brand','Category','Price','Reviews','Avg Rating','% Positive',''],ps.filter(p=>(!c||p.category===c)&&p.name.toLowerCase().includes(q)).map(p=>[`<b>${esc(p.name)}</b>`,esc(p.brand),esc(p.category),'₹'+Number(p.price).toLocaleString('en-IN'),p.reviews,p.avg_rating??'-',(p.pos_pct??'-')+'%',`<a href="#/product/${p.id}">Details →</a>`])); };
  setTimeout(()=>{ pq.oninput=pc.onchange=f; f(); });
  return `<div class="bar"><input id="pq" placeholder="Search products…"><select id="pc"><option value="">All categories</option>${CATS.map(c=>`<option>${c}</option>`).join('')}</select></div><div class="card" id="plist"></div>`;
 },
 async product(id){
  const p = await api('/products/'+id);
  return [`<p><a href="#/products">← Products</a></p><div class="card"><h3>${esc(p.name)} <span>${bd(p.category)}</span></h3><p class="mu">${esc(p.brand)} · ${esc(p.model)} · ₹${Number(p.price).toLocaleString('en-IN')} — ${esc(p.description)}</p>
   <div class="cards">${stat('Reviews',p.total)}${stat('Avg Rating',p.avg_rating)}${stat('Positive',p.pct.Positive+'%')}${stat('Negative',p.pct.Negative+'%')}</div><p><b>Opinion summary:</b> ${esc(p.summary)}</p></div>
   <div class="g2">${panel('Aspect-wise Sentiment',cv('p1',280))}${panel('Sentiment Split',cv('p2',280))}</div>
   ${p.issues.length?panel('Recurring Issues',tbl(['Aspect','Complaint mentions','Negative %','Status'],p.issues.map(i=>[i.aspect,i.mentions,i.negative_pct+'%',bd(i.status)]))):''}
   ${panel('Recent Reviews',tbl(['Date','Review','Rating','Sentiment','Aspects'],p.reviews.map(r=>[fmt(r.created_at),esc(r.review_text),'★'.repeat(r.rating),bd(r.sentiment),aspBd(r.aspects)])))}`,
   ()=>{ chart('p1',{type:'bar',data:{labels:p.aspects.map(a=>a.aspect),datasets:[{label:'Positive %',data:p.aspects.map(a=>a.positive_pct),backgroundColor:COL.Positive},{label:'Negative %',data:p.aspects.map(a=>a.negative_pct),backgroundColor:COL.Negative}]},options:{scales:{y:{max:100}}}});
         chart('p2',{type:'doughnut',data:{labels:Object.keys(p.sentiment),datasets:[{data:Object.values(p.sentiment),backgroundColor:sentCols(p.sentiment)}]}}); }];
 },
 async submit(){
  const ps = await api('/products');
  setTimeout(()=>{
    const sample = {Refrigerator:'The refrigerator has excellent cooling and looks beautiful, but it consumes too much electricity and the compressor is noisy.','Washing Machine':'The washing machine cleans clothes very well but makes a lot of noise during spinning.'};
    sp.onchange=()=>{ const c=ps.find(p=>p.id==sp.value).category; if(sample[c]) rt.value=sample[c]; }; sp.onchange();
    document.getElementById('sub').onclick=async()=>{ try{ const r=await api('/reviews',{method:'POST',body:{product_id:+sp.value,review_text:rt.value,rating:+rr.value}});
      out.innerHTML=`<div class="card"><h3>Review received ${bd('received')}</h3><p>Review #${r.id} stored. Processing status: <b>received</b>.</p><button id="an">Analyze Review</button></div>`;
      document.getElementById('an').onclick=async()=>{ const a=await api(`/reviews/${r.id}/analyze`,{method:'POST'}); out.innerHTML=panel(`ASMA Analysis – Review #${r.id}`,analysisView(a),bd('analyzed')); }; }catch(e){ out.innerHTML=`<div class="card" style="color:#dc2626">${esc(e.message)}</div>`; } };
  });
  return `<div class="card"><h3>Submit a customer review</h3><div class="fg"><label>Appliance<select id="sp">${ps.map(p=>`<option value="${p.id}">${esc(p.name)}</option>`).join('')}</select></label><label>Rating<select id="rr">${[5,4,3,2,1].map(n=>`<option>${n}</option>`).join('')}</select></label></div>
  <p><label class="mu">Your review</label><textarea id="rt"></textarea></p><button id="sub">Submit Review</button></div><div id="out"></div>`;
 },
 async reviews(){
  const ps = await api('/products'), canDel = T.user.role==='admin';
  const load = async()=>{ const q=new URLSearchParams({product_id:fp.value,sentiment:fs.value,q:fq.value}); [...q].forEach(([k,v])=>!v&&q.delete(k));
    const rs = await api('/reviews?'+q); document.getElementById('rl').innerHTML=tbl(['ID','Date','Product','User','Review','Sentiment','Aspects','Status',''],rs.map(r=>[r.id,fmt(r.created_at),esc(r.product),esc(r.user),esc(r.review_text),bd(r.sentiment||'-'),aspBd(r.aspects),bd(r.processing_status),
      `<button class="sec" onclick="showRev(${r.id})">View</button>${r.processing_status!=='analyzed'?` <button onclick="anRev(${r.id})">Analyze</button>`:''}${canDel?` <button class="dng" onclick="delRev(${r.id})">Delete</button>`:''}`])); };
  window.reload=load; setTimeout(()=>{ fp.onchange=fs.onchange=load; fq.oninput=load; load(); });
  return `<div class="bar"><select id="fp"><option value="">All products</option>${ps.map(p=>`<option value="${p.id}">${esc(p.name)}</option>`).join('')}</select><select id="fs"><option value="">All sentiments</option>${['Positive','Negative','Neutral','Mixed'].map(s=>`<option>${s}</option>`).join('')}</select><input id="fq" placeholder="Search review text…"></div><div id="detail"></div><div class="card" id="rl"></div>`;
 },
 async analytics(){
  const [ps, d0] = [await api('/products'), null];
  const load = async()=>{ const q=af.value?(af.value.startsWith('c:')?'category='+encodeURIComponent(af.value.slice(2)):'product_id='+af.value.slice(2)):''; const d=await api('/analytics?'+q);
    res.innerHTML = `<div class="card"><b>Summary:</b> ${esc(d.summary)}</div><div class="g2">${panel('Aspect Sentiment (% of mentions)',cv('a1',320))}${panel('Sentiment Distribution',cv('a2',320))}</div>
     <div class="g2">${panel('Trending Issues (negative mentions)',tbl(['Aspect','Negative mentions','Negative %'],d.trending.map(t=>[t.aspect,t.negative,t.negative_pct+'%'])))}${panel('Top Keywords',d.keywords.map(k=>`<span class="bd new">${esc(k[0])} · ${k[1]}</span>`).join(''))}</div>
     ${panel('Aspect Detail',tbl(['Aspect','Mentions','Positive','Negative','Neutral','Positive %','Negative %'],d.aspects.map(a=>[a.aspect,a.mentions,a.positive,a.negative,a.neutral,a.positive_pct+'%',a.negative_pct+'%'])))}`;
    chart('a1',{type:'bar',data:{labels:d.aspects.map(a=>a.aspect),datasets:[{label:'Positive %',data:d.aspects.map(a=>a.positive_pct),backgroundColor:COL.Positive},{label:'Negative %',data:d.aspects.map(a=>a.negative_pct),backgroundColor:COL.Negative}]},options:{indexAxis:'y',scales:{x:{max:100}}}});
    chart('a2',{type:'pie',data:{labels:Object.keys(d.sentiment),datasets:[{data:Object.values(d.sentiment),backgroundColor:sentCols(d.sentiment)}]}}); };
  setTimeout(()=>{ af.onchange=load; load(); });
  return `<div class="bar"><label>Filter:</label><select id="af"><option value="">All products</option>${CATS.map(c=>`<option value="c:${c}">Category: ${c}</option>`).join('')}${ps.map(p=>`<option value="p:${p.id}">${esc(p.name)}</option>`).join('')}</select></div><div id="res"></div>`;
 },
 async compare(){
  const ps = await api('/products'), opts = sel => ps.map((p,i)=>`<option value="${p.id}" ${i===sel?'selected':''}>${esc(p.name)}</option>`).join('');
  const load = async()=>{ try{ const [A,B]=await api(`/compare?a=${ca.value}&b=${cb.value}`); const names=[A.name,B.name]; const aspects=[...new Set([...A.aspects,...B.aspects].map(x=>x.aspect))]; const pick=(P,k)=>aspects.map(a=>(P.aspects.find(x=>x.aspect===a)||{})[k]||0);
    const col=P=>`<td><b>${esc(P.name)}</b></td>`;
    cmp.innerHTML = `${panel('Overview',tbl(['Metric',esc(A.name),esc(B.name)],[['Total reviews',A.total,B.total],['Average rating',A.avg_rating,B.avg_rating],['Positive %',A.pct.Positive+'%',B.pct.Positive+'%'],['Negative %',A.pct.Negative+'%',B.pct.Negative+'%'],['Neutral %',A.pct.Neutral+'%',B.pct.Neutral+'%'],['Mixed %',A.pct.Mixed+'%',B.pct.Mixed+'%'],
      ['Most common complaints',A.complaints.map(x=>bd(x.aspect+' ('+x.negative+')').replace('bd','bd negative')).join(''),B.complaints.map(x=>bd(x.aspect+' ('+x.negative+')').replace('bd','bd negative')).join('')],
      ['Most appreciated',A.appreciated.map(x=>bd(x.aspect+' ('+x.positive+')').replace('bd','bd positive')).join(''),B.appreciated.map(x=>bd(x.aspect+' ('+x.positive+')').replace('bd','bd positive')).join('')],
      ['Summary',esc(A.summary),esc(B.summary)]]))}
      <div class="g2">${panel('Sentiment Split (%)',cv('k1',280))}${panel('Aspect-wise Positive %',cv('k2',280))}</div>${panel('Aspect-wise Negative %',cv('k3',280))}`;
    chart('k1',{type:'bar',data:{labels:['Positive','Negative','Neutral','Mixed'],datasets:[A,B].map((P,i)=>({label:P.name,data:['Positive','Negative','Neutral','Mixed'].map(k=>P.pct[k]),backgroundColor:i?'#f59e0b':'#2563eb'}))}});
    chart('k2',{type:'bar',data:{labels:aspects,datasets:[A,B].map((P,i)=>({label:P.name,data:pick(P,'positive_pct'),backgroundColor:i?'#f59e0b':'#2563eb'}))}});
    chart('k3',{type:'bar',data:{labels:aspects,datasets:[A,B].map((P,i)=>({label:P.name,data:pick(P,'negative_pct'),backgroundColor:i?'#f59e0b':'#2563eb'}))}}); }catch(e){ cmp.innerHTML=`<div class="card" style="color:#dc2626">${esc(e.message)}</div>`; } };
  setTimeout(()=>{ ca.onchange=cb.onchange=load; load(); });
  return `<div class="bar"><select id="ca">${opts(0)}</select><b>vs</b><select id="cb">${opts(1)}</select></div><div id="cmp"></div>`;
 },
 async issues(){
  const is = await api('/issues'), pm = T.user.role==='product_manager'||T.user.role==='admin';
  window.setIssue = async(id,st)=>{ const note=prompt('Add a note for this status change (optional):')??''; await api('/issues/'+id,{method:'PUT',body:{status:st,note}}); route(); };
  window.hist = async id=>{ const u=await api(`/issues/${id}/updates`); document.getElementById('ih').innerHTML=panel('Status history – issue #'+id,tbl(['When','By','Change','Note'],u.map(x=>[x.created_at,esc(x.user),`${bd(x.old_status||'-')} → ${bd(x.new_status)}`,esc(x.note)]))); };
  return `<p class="mu">Issues are auto-detected when an aspect has ≥3 negative mentions and ≥40% negative sentiment for a product.</p><div id="ih"></div>
   ${panel('Recurring Issues',tbl(['#','Product','Issue','Mentions','Sentiment','Status','Update status',''],is.map(i=>[i.id,esc(i.product),`<b>${esc(i.aspect)}</b>`,i.mentions,i.negative_pct>=60?'Mostly Negative':'Mixed',bd(i.status),
    pm?`<select onchange="setIssue(${i.id},this.value)">${['New','Under Review','In Progress','Resolved'].map(s=>`<option ${s===i.status?'selected':''}>${s}</option>`).join('')}</select>`:'<span class="mu">read-only</span>',`<button class="sec" onclick="hist(${i.id})">History</button>`])))}`;
 },
 async reports(){
  const ps = await api('/products');
  const kinds = [['product_opinion','Product Opinion'],['sentiment','Customer Sentiment'],['aspect','Aspect Analysis'],['recurring','Recurring Complaint'],['comparison','Product Comparison']];
  let cur = null;
  window.showReport = async k=>{ const q=k==='comparison'?`?a=${ra.value}&b=${rb.value}`:''; const r=await api('/reports/'+k+q); cur=k+q;
    rep.innerHTML=panel(esc(r.title)+' <span class="mu">'+new Date().toLocaleDateString()+'</span>',tbl(r.columns.map(esc),r.rows.map(x=>x.map(esc))),'<span class="noprint"><button onclick="dl()">Download CSV</button> <button class="sec" onclick="window.print()">Print / Save PDF</button></span>'); };
  window.dl = ()=>{ const [k,q]=cur.split('?'); download(`/reports/${k}?${q?q+'&':''}format=csv`,k+'_report.csv'); };
  return `<div class="bar noprint">${kinds.map(k=>`<button class="sec" onclick="showReport('${k[0]}')">${k[1]}</button>`).join('')}<select id="ra">${ps.map((p,i)=>`<option value="${p.id}">${esc(p.name)}</option>`).join('')}</select><select id="rb">${ps.map((p,i)=>`<option value="${p.id}" ${i===1?'selected':''}>${esc(p.name)}</option>`).join('')}</select><span class="mu">(products used for comparison report)</span></div><div id="rep"><div class="card mu">Choose a report above.</div></div>`;
 },
 async itpm(){
  const d = await api('/itpm'); let tab = 'charter';
  const views = {
   charter:()=>{ const c=d.charter; return panel('Project Charter',`<p><b>Project:</b> ${esc(c.name)}<br><b>Organization:</b> ${esc(c.organization)}</p><p><b>Problem statement:</b> ${esc(c.problem)}</p><b>Objectives</b><ul>${c.objectives.map(o=>`<li>${esc(o)}</li>`).join('')}</ul>
     <div class="g2"><div><b>In scope</b><ul>${c.scope.in.map(o=>`<li>${esc(o)}</li>`).join('')}</ul></div><div><b>Out of scope</b><ul>${c.scope.out.map(o=>`<li>${esc(o)}</li>`).join('')}</ul></div></div>
     <b>Stakeholders</b>${tbl(['Stakeholder','Interest'],c.stakeholders.map(s=>s.map(esc)))}<b>Deliverables</b><ul>${c.deliverables.map(o=>`<li>${esc(o)}</li>`).join('')}</ul>`); },
   wbs:()=>{ const t=n=>`<li>${n.children?`<b>${esc(n.name)}</b><ul>${n.children.map(t).join('')}</ul>`:esc(n.name)}</li>`; return panel('Work Breakdown Structure',`<ul class="tree">${t(d.wbs)}</ul>`); },
   gantt:()=>panel('Gantt Chart – 10 weeks from '+d.weeks_start,`<div class="gh"><span></span>${[...Array(10)].map((_,i)=>`<span>W${i+1}</span>`).join('')}</div>${d.gantt.map(g=>`<div class="gr"><span>${esc(g.name)}<br><span class="mu">${esc(g.o)} · ${g.p}%</span></span><div class="gt"><i style="left:${(g.s-1)*10}%;width:${(g.e-g.s+1)*10}%"><b style="width:${g.p}%"></b></i></div></div>`).join('')}`),
   tasks:()=>panel('Task Management',tbl(['#','Task','Member','Status','Priority','Start','Due','Completion'],d.tasks.map(t=>[t.id,esc(t.name),esc(t.member),
     `<select onchange="upTask(${t.id},{status:this.value})">${['Not Started','In Progress','Completed','Blocked'].map(s=>`<option ${s===t.status?'selected':''}>${s}</option>`).join('')}</select>`,bd(t.priority),t.start,t.due,
     `<div class="pr"><i style="width:${t.pct}%"></i></div><input type="number" min="0" max="100" value="${t.pct}" style="width:64px" onchange="upTask(${t.id},{pct:+this.value})">%`]))),
   team:()=>`<div class="g2">${d.team.map(m=>panel(esc(m.name),`<p>${bd(m.role)}</p><ul>${m.resp.map(r=>`<li>${esc(r)}</li>`).join('')}</ul>${tbl(['Assigned tasks'],d.tasks.filter(t=>t.member===m.name).map(t=>[esc(t.name)+' '+bd(t.status)]))}`)).join('')}</div>`,
   risks:()=>panel('Risk Register',tbl(['ID','Risk','Probability','Impact','Severity','Mitigation','Status'],d.risks.map(r=>{const s=r.p*r.i; return [r.id,esc(r.risk),r.p+'/5',r.i+'/5',bd(s>=15?'High':s>=8?'Medium':'Low')+' '+s,esc(r.mitigation),bd(r.status)];}))),
   testing:()=>{ const p=d.tests.filter(t=>t.status==='Passed').length; return panel(`Testing Management – ${p}/${d.tests.length} passed`,tbl(['Test Case','Feature','Input','Expected','Actual','Status'],d.tests.map(t=>[t.id,esc(t.feature),esc(t.input),esc(t.expected),esc(t.actual),bd(t.status)])),'<button onclick="runTests()">Run all tests</button>'); }};
  window.upTask = async(id,b)=>{ await api('/itpm/tasks/'+id,{method:'PUT',body:b}); Object.assign(d.tasks.find(t=>t.id===id),b); draw(); };
  window.runTests = async()=>{ d.tests=await api('/itpm/tests/run',{method:'POST'}); draw(); };
  window.draw = ()=>{ itb.innerHTML=Object.keys(views).map(k=>`<button class="${k===tab?'on':''}" onclick="tab_('${k}')">${k==='wbs'?'WBS':k[0].toUpperCase()+k.slice(1)}</button>`).join(''); itc.innerHTML=views[tab](); };
  window.tab_ = k=>{ tab=k; draw(); };
  setTimeout(draw); return `<div class="tabs" id="itb"></div><div id="itc"></div>`;
 },
 async integration(){
  const m = [['ASMA – Advanced Social Text & Media Analysis','Intelligence / text analysis',[['NLP preprocessing (clean, tokenize, normalize)','#/reviews'],['Sentiment analysis (Pos/Neg/Neu/Mixed)','#/reviews'],['Aspect extraction','#/analytics'],['Opinion mining','#/reviews'],['Keyword extraction','#/analytics'],['Review classification','#/reviews'],['Aggregate opinions & trending issues','#/analytics'],['Text summarization','#/products']]],
   ['Enterprise Systems','Organizational data, roles, workflow',[['Authentication & roles (4)','#/users'],['Product management (CRUD)','#/admin'],['Review management & status workflow','#/reviews'],['Relational database (8 tables)','#/dashboard'],['Issue management workflow','#/issues'],['Analytics dashboard','#/dashboard'],['Reports (CSV / PDF)','#/reports']]],
   ['IT Project Management','Planning, development, testing',[['Project charter & scope','#/itpm'],['Work breakdown structure','#/itpm'],['Gantt chart','#/itpm'],['Task management','#/itpm'],['Team allocation','#/itpm'],['Risk management','#/itpm'],['Testing management','#/itpm'],['Deployment & maintenance (README, re-seed script)','#/itpm']]]];
  return `<div class="card"><b>One application, three subjects.</b> Reviews flow: Customer → Enterprise workflow → ASMA engine → Database → Manager dashboard → Issue → Resolution, planned and tested under ITPM.</div><div class="map">${m.map(x=>panel(x[0],`<p class="mu">${x[1]}</p><ul>${x[2].map(f=>MENU[T.user.role].includes(f[1].slice(2))?`<li><a href="${f[1]}">${f[0]}</a></li>`:`<li>${f[0]} <span class="mu">(${f[1].slice(2)} – not available for your role)</span></li>`).join('')}</ul>`)).join('')}</div>`;
 },
 async admin(){
  const ps = await api('/products');
  window.editP = id=>{ const p=ps.find(x=>x.id===id)||{}; pid.value=p.id||''; pn.value=p.name||''; pb.value=p.brand||''; pcat.value=p.category||CATS[0]; pm.value=p.model||''; ppr.value=p.price||''; pd.value=p.description||''; };
  window.delP = async id=>{ if(confirm('Delete this product and its reviews?')){ await api('/products/'+id,{method:'DELETE'}); route(); } };
  window.saveP = async()=>{ const b={name:pn.value,brand:pb.value,category:pcat.value,model:pm.value,price:+ppr.value,description:pd.value}; try{ await api('/products'+(pid.value?'/'+pid.value:''),{method:pid.value?'PUT':'POST',body:b}); route(); }catch(e){ alert(e.message); } };
  return `${panel('Add / Edit Product',`<input type="hidden" id="pid"><div class="fg"><label>Name<input id="pn"></label><label>Brand<input id="pb"></label><label>Category<select id="pcat">${CATS.map(c=>`<option>${c}</option>`).join('')}</select></label><label>Model<input id="pm"></label><label>Price (₹)<input id="ppr" type="number"></label><label>Description<input id="pd"></label></div><p><button onclick="saveP()">Save product</button> <button class="sec" onclick="editP(0)">Clear</button></p>`)}
  ${panel('Products',tbl(['ID','Name','Brand','Category','Model','Price','Reviews','Actions'],ps.map(p=>[p.id,esc(p.name),esc(p.brand),esc(p.category),esc(p.model),p.price,p.reviews,`<button class="sec" onclick="editP(${p.id})">Edit</button> <button class="dng" onclick="delP(${p.id})">Delete</button>`])))}`;
 },
 async users(){
  const us = await api('/users'), R=['customer','analyst','product_manager','admin'];
  window.setRole = async(id,r)=>{ await api('/users/'+id,{method:'PUT',body:{role:r}}); route(); };
  window.delU = async id=>{ try{ if(confirm('Delete user?')){ await api('/users/'+id,{method:'DELETE'}); route(); } }catch(e){ alert(e.message); } };
  window.addU = async()=>{ try{ await api('/users',{method:'POST',body:{name:un.value,email:ue.value,password:up.value,role:ur.value}}); route(); }catch(e){ alert(e.message); } };
  return `${panel('Add User',`<div class="fg"><label>Name<input id="un"></label><label>Email<input id="ue"></label><label>Password<input id="up" type="password"></label><label>Role<select id="ur">${R.map(r=>`<option>${r}</option>`).join('')}</select></label></div><p><button onclick="addU()">Create user</button></p>`)}
  ${panel('Users & Roles',tbl(['ID','Name','Email','Role','Created',''],us.map(u=>[u.id,esc(u.name),esc(u.email),`<select onchange="setRole(${u.id},this.value)">${R.map(r=>`<option ${r===u.role?'selected':''}>${r}</option>`).join('')}</select>`,fmt(u.created_at),u.id===T.user.id?'':`<button class="dng" onclick="delU(${u.id})">Delete</button>`])))}`;
 }};
window.showRev = async id=>{ const r=await api('/reviews/'+id); document.getElementById('detail').innerHTML=panel(`Review #${id} – ${esc(r.product)}`,`<p>“${esc(r.review_text)}” ${'★'.repeat(r.rating)}</p>`+(r.opinions.length||r.processing_status==='analyzed'?analysisView(r):'<p class="mu">Not analyzed yet.</p>')); scrollTo(0,0); };
window.anRev = async id=>{ await api(`/reviews/${id}/analyze`,{method:'POST'}); await reload(); showRev(id); };
window.delRev = async id=>{ if(confirm('Delete review?')){ await api('/reviews/'+id,{method:'DELETE'}); reload(); } };
boot();

import csv, io, json, sys, pathlib, functools
ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / "backend")]
from flask import Flask, jsonify, request, g, Response
from itsdangerous import URLSafeTimedSerializer
from werkzeug.security import check_password_hash, generate_password_hash
import services as S
from asma.engine import analyze_review, preprocess, aggregate, summarize, trending_issues

app = Flask(__name__, static_folder=str(ROOT / "frontend"), static_url_path="")
ser = URLSafeTimedSerializer("hometech-demo-secret")
ITPM = ROOT / "data" / "itpm.json"
CATS = ["Refrigerator", "Washing Machine", "Air Conditioner", "Microwave Oven", "Vacuum Cleaner"]
ROLES = ["customer", "analyst", "product_manager", "admin"]
STATUSES = ["New", "Under Review", "In Progress", "Resolved"]
if not S.DB.exists(): S.init_db()

@app.teardown_appcontext
def _close(e):
    d = g.pop("db", None)
    if d: d.close()
def db():
    if "db" not in g: g.db = S.connect()
    return g.db
def rows(sql, a=()): return [dict(r) for r in db().execute(sql, a).fetchall()]
def one(sql, a=()):
    r = db().execute(sql, a).fetchone(); return dict(r) if r else None
def err(m, c=400): return jsonify(error=m), c

def auth(*roles):
    def deco(f):
        @functools.wraps(f)
        def w(*a, **k):
            try: uid = ser.loads(request.headers.get("Authorization", "")[7:], max_age=86400)["id"]
            except Exception: return err("Unauthorized", 401)
            u = one("SELECT id,name,email,role FROM users WHERE id=?", (uid,))
            if not u: return err("Unauthorized", 401)
            if roles and u["role"] not in roles and u["role"] != "admin": return err("Forbidden for role " + u["role"], 403)
            g.user = u; return f(*a, **k)
        return w
    return deco

@app.route("/")
def index(): return app.send_static_file("index.html")

# ---------- auth ----------
@app.post("/api/auth/login")
def login():
    d = request.json or {}
    u = one("SELECT * FROM users WHERE email=?", (d.get("email", "").lower(),))
    if not u or not check_password_hash(u["password_hash"], d.get("password", "")): return err("Invalid email or password", 401)
    return jsonify(token=ser.dumps({"id": u["id"]}), user={k: u[k] for k in ("id", "name", "email", "role")})

@app.post("/api/auth/register")
def register():
    d = request.json or {}
    if not all(d.get(k) for k in ("name", "email", "password")): return err("name, email, password required")
    if one("SELECT 1 FROM users WHERE email=?", (d["email"].lower(),)): return err("Email already registered")
    db().execute("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,'customer')", (d["name"], d["email"].lower(), generate_password_hash(d["password"])))
    db().commit(); return jsonify(ok=True), 201

@app.get("/api/me")
@auth()
def me(): return jsonify(g.user)

# ---------- helpers ----------
def analyses(where="1=1", a=()):
    d = {}
    for r in db().execute(f"""SELECT o.review_id rid, s.name aspect, o.sentiment sentiment FROM opinions o JOIN aspects s ON s.id=o.aspect_id
        JOIN reviews r ON r.id=o.review_id JOIN products p ON p.id=r.product_id WHERE {where}""", a):
        d.setdefault(r["rid"], {"opinions": []})["opinions"].append({"aspect": r["aspect"], "sentiment": r["sentiment"]})
    return list(d.values())
def agg_list(ag): return sorted(({"aspect": k, **v} for k, v in ag.items()), key=lambda x: -x["mentions"])
def sent_counts(where="1=1", a=()):
    c = {"Positive": 0, "Negative": 0, "Neutral": 0, "Mixed": 0}
    for r in db().execute(f"""SELECT a.overall_sentiment s, COUNT(*) n FROM review_analysis a JOIN reviews r ON r.id=a.review_id
        JOIN products p ON p.id=r.product_id WHERE {where} GROUP BY 1""", a): c[r["s"]] = r["n"]
    return c
def pstats(pid):
    p = one("SELECT * FROM products WHERE id=?", (pid,))
    if not p: return None
    s = sent_counts("p.id=?", (pid,)); n = sum(s.values())
    p.update(total=n, avg_rating=(one("SELECT ROUND(AVG(rating),2) v FROM reviews WHERE product_id=?", (pid,)) or {}).get("v") or 0, sentiment=s,
             pct={k: round(100 * v / n) if n else 0 for k, v in s.items()})
    ag = aggregate(analyses("p.id=?", (pid,))); p["aspects"] = agg_list(ag)
    p["summary"] = summarize(ag, "the " + p["name"]); p["trending"] = trending_issues(ag, 2)
    return p
REV_SQL = """SELECT r.id, r.review_text, r.rating, r.created_at, r.processing_status, p.name product, p.id product_id, p.category, u.name user,
  a.overall_sentiment sentiment, (SELECT group_concat(s.name||':'||o.sentiment, '|') FROM opinions o JOIN aspects s ON s.id=o.aspect_id WHERE o.review_id=r.id) aspects
  FROM reviews r JOIN products p ON p.id=r.product_id JOIN users u ON u.id=r.user_id LEFT JOIN review_analysis a ON a.review_id=r.id """

# ---------- products ----------
@app.get("/api/products")
@auth()
def products():
    return jsonify(rows("""SELECT p.*, COUNT(a.id) reviews, ROUND((SELECT AVG(rating) FROM reviews WHERE product_id=p.id),2) avg_rating,
      ROUND(100.0*SUM(a.overall_sentiment='Positive')/NULLIF(COUNT(a.id),0)) pos_pct FROM products p LEFT JOIN reviews r ON r.product_id=p.id
      LEFT JOIN review_analysis a ON a.review_id=r.id GROUP BY p.id"""))

@app.get("/api/products/<int:pid>")
@auth()
def product(pid):
    p = pstats(pid)
    if not p: return err("Not found", 404)
    p["reviews"] = rows(REV_SQL + "WHERE r.product_id=? ORDER BY r.created_at DESC LIMIT 10", (pid,))
    p["issues"] = rows("SELECT i.*, a.name aspect FROM issues i JOIN aspects a ON a.id=i.aspect_id WHERE product_id=? ORDER BY mentions DESC", (pid,))
    return jsonify(p)

def pvalid(d):
    if not d.get("name") or not d.get("brand") or d.get("category") not in CATS: return "name, brand and a valid category are required"
@app.post("/api/products")
@auth("admin")
def p_add():
    d = request.json or {}; e = pvalid(d)
    if e: return err(e)
    c = db().execute("INSERT INTO products(name,brand,category,model,price,description) VALUES(?,?,?,?,?,?)",
                     (d["name"], d["brand"], d["category"], d.get("model"), d.get("price") or 0, d.get("description")))
    db().commit(); return jsonify(id=c.lastrowid), 201
@app.put("/api/products/<int:pid>")
@auth("admin")
def p_edit(pid):
    d = request.json or {}; e = pvalid(d)
    if e: return err(e)
    db().execute("UPDATE products SET name=?,brand=?,category=?,model=?,price=?,description=? WHERE id=?",
                 (d["name"], d["brand"], d["category"], d.get("model"), d.get("price") or 0, d.get("description"), pid))
    db().commit(); return jsonify(ok=True)
@app.delete("/api/products/<int:pid>")
@auth("admin")
def p_del(pid):
    db().execute("DELETE FROM products WHERE id=?", (pid,)); db().commit(); return jsonify(ok=True)

# ---------- reviews & analysis ----------
@app.get("/api/reviews")
@auth()
def reviews():
    w, a = [], []
    if g.user["role"] == "customer": w.append("r.user_id=?"); a.append(g.user["id"])
    for k, col in (("product_id", "r.product_id"), ("sentiment", "a.overall_sentiment"), ("category", "p.category")):
        if request.args.get(k): w.append(col + "=?"); a.append(request.args[k])
    if request.args.get("q"): w.append("r.review_text LIKE ?"); a.append("%" + request.args["q"] + "%")
    return jsonify(rows(REV_SQL + ("WHERE " + " AND ".join(w) if w else "") + " ORDER BY r.created_at DESC LIMIT 200", a))

def review_detail(rid):
    r = one(REV_SQL + "WHERE r.id=?", (rid,))
    if not r: return None
    r["opinions"] = rows("SELECT s.name aspect, o.opinion_text opinion, o.sentiment, o.score FROM opinions o JOIN aspects s ON s.id=o.aspect_id WHERE o.review_id=?", (rid,))
    an = one("SELECT * FROM review_analysis WHERE review_id=?", (rid,)) or {}
    r.update(keywords=[k for k in (an.get("keywords") or "").split(",") if k], predicted_category=an.get("predicted_category"),
             sentiment_score=an.get("sentiment_score"), cleaned_text=an.get("cleaned_text"), tokens=preprocess(r["review_text"])["tokens"])
    return r

def own_or_staff(rid):
    r = one("SELECT user_id FROM reviews WHERE id=?", (rid,))
    return r and (g.user["role"] != "customer" or r["user_id"] == g.user["id"])

@app.get("/api/reviews/<int:rid>")
@auth()
def review_get(rid):
    if not own_or_staff(rid): return err("Not found", 404)
    return jsonify(review_detail(rid))

@app.post("/api/reviews")
@auth("customer")
def review_add():
    d = request.json or {}
    text = (d.get("review_text") or "").strip()
    if len(text) < 10: return err("Review must be at least 10 characters")
    if not one("SELECT 1 FROM products WHERE id=?", (d.get("product_id"),)): return err("Unknown product")
    if d.get("rating") not in (1, 2, 3, 4, 5): return err("Rating must be 1-5")
    c = db().execute("INSERT INTO reviews(user_id,product_id,review_text,rating) VALUES(?,?,?,?)", (g.user["id"], d["product_id"], text, d["rating"]))
    db().commit(); return jsonify(id=c.lastrowid, processing_status="received"), 201

@app.post("/api/reviews/<int:rid>/analyze")
@auth()
def review_analyze(rid):
    if not own_or_staff(rid): return err("Not found", 404)
    r = one("SELECT review_text, rating FROM reviews WHERE id=?", (rid,))
    S.save_analysis(db(), rid, analyze_review(r["review_text"], r["rating"])); S.detect_issues(db()); db().commit()
    return jsonify(review_detail(rid))

@app.post("/api/analyze")
@auth()
def preview(): return jsonify(analyze_review((request.json or {}).get("text", ""), (request.json or {}).get("rating")))

@app.put("/api/reviews/<int:rid>")
@auth("admin")
def review_edit(rid):
    d = request.json or {}
    db().execute("UPDATE reviews SET review_text=?, rating=? WHERE id=?", (d.get("review_text"), d.get("rating"), rid)); db().commit()
    r = one("SELECT review_text, rating FROM reviews WHERE id=?", (rid,))
    S.save_analysis(db(), rid, analyze_review(r["review_text"], r["rating"])); S.detect_issues(db()); db().commit()
    return jsonify(ok=True)
@app.delete("/api/reviews/<int:rid>")
@auth("admin")
def review_del(rid):
    db().execute("DELETE FROM reviews WHERE id=?", (rid,)); db().commit(); return jsonify(ok=True)

# ---------- dashboard / analytics / compare ----------
@app.get("/api/dashboard")
@auth("analyst", "product_manager")
def dashboard():
    s = sent_counts(); ag = agg_list(aggregate(analyses()))
    trend = {}
    for r in db().execute("""SELECT date(r.created_at,'weekday 0','-6 days') wk, a.overall_sentiment s, COUNT(*) n FROM reviews r
        JOIN review_analysis a ON a.review_id=r.id GROUP BY 1,2 ORDER BY 1"""):
        trend.setdefault(r["wk"], {"Positive": 0, "Negative": 0, "Neutral": 0, "Mixed": 0})[r["s"]] = r["n"]
    return jsonify(products=one("SELECT COUNT(*) n FROM products")["n"], reviews=sum(s.values()), sentiment=s,
        trend=[{"week": k, **v} for k, v in trend.items()], aspects=ag,
        product_compare=[{"name": p["name"], "pos_pct": p["pos_pct"] or 0, "avg_rating": p["avg_rating"]} for p in rows("""SELECT p.name, ROUND((SELECT AVG(rating) FROM reviews WHERE product_id=p.id),2) avg_rating,
          ROUND(100.0*SUM(a.overall_sentiment='Positive')/NULLIF(COUNT(a.id),0)) pos_pct FROM products p LEFT JOIN reviews r ON r.product_id=p.id LEFT JOIN review_analysis a ON a.review_id=r.id GROUP BY p.id""")],
        top_complaints=rows("""SELECT p.name product, s.name aspect, i.mentions, i.negative_pct, i.status FROM issues i JOIN products p ON p.id=i.product_id
          JOIN aspects s ON s.id=i.aspect_id ORDER BY i.mentions DESC LIMIT 8"""),
        recent=rows(REV_SQL + "ORDER BY r.created_at DESC LIMIT 8"),
        attention=rows("""SELECT i.id, p.name product, s.name aspect, i.mentions, i.negative_pct, i.status FROM issues i JOIN products p ON p.id=i.product_id
          JOIN aspects s ON s.id=i.aspect_id WHERE i.status!='Resolved' ORDER BY i.mentions DESC LIMIT 6"""))

@app.get("/api/analytics")
@auth("analyst", "product_manager")
def analytics():
    pid, cat = request.args.get("product_id"), request.args.get("category")
    w, a = ("p.id=?", (pid,)) if pid else ("p.category=?", (cat,)) if cat else ("1=1", ())
    ag = aggregate(analyses(w, a)); kw = {}
    for r in db().execute(f"SELECT a.keywords k FROM review_analysis a JOIN reviews r ON r.id=a.review_id JOIN products p ON p.id=r.product_id WHERE {w}", a):
        for k in r["k"].split(","): kw[k] = kw.get(k, 0) + 1
    return jsonify(aspects=agg_list(ag), sentiment=sent_counts(w, a), trending=[{"aspect": x, "negative": n, "negative_pct": p} for x, n, p in trending_issues(ag, 2)],
                   summary=summarize(ag, "these products"), keywords=sorted(kw.items(), key=lambda x: -x[1])[:15])

@app.get("/api/compare")
@auth("analyst", "product_manager")
def compare():
    out = []
    for k in ("a", "b"):
        p = pstats(request.args.get(k))
        if not p: return err("Select two valid products")
        ag = p["aspects"]
        p["complaints"] = sorted([x for x in ag if x["negative"]], key=lambda x: -x["negative"])[:3]
        p["appreciated"] = sorted([x for x in ag if x["positive"]], key=lambda x: -x["positive"])[:3]
        out.append(p)
    return jsonify(out)

# ---------- issues ----------
@app.get("/api/issues")
@auth("analyst", "product_manager")
def issues():
    return jsonify(rows("""SELECT i.*, p.name product, s.name aspect FROM issues i JOIN products p ON p.id=i.product_id
      JOIN aspects s ON s.id=i.aspect_id ORDER BY (i.status='Resolved'), i.mentions DESC"""))
@app.get("/api/issues/<int:iid>/updates")
@auth("analyst", "product_manager")
def issue_updates(iid):
    return jsonify(rows("SELECT u.*, x.name user FROM issue_updates u JOIN users x ON x.id=u.user_id WHERE issue_id=? ORDER BY u.id DESC", (iid,)))
@app.put("/api/issues/<int:iid>")
@auth("product_manager")
def issue_set(iid):
    d = request.json or {}; i = one("SELECT status FROM issues WHERE id=?", (iid,))
    if not i or d.get("status") not in STATUSES: return err("Invalid issue or status")
    db().execute("UPDATE issues SET status=?, assigned_to=?, updated_at=CURRENT_TIMESTAMP WHERE id=?", (d["status"], g.user["id"], iid))
    db().execute("INSERT INTO issue_updates(issue_id,user_id,old_status,new_status,note) VALUES(?,?,?,?,?)", (iid, g.user["id"], i["status"], d["status"], d.get("note", "")))
    db().commit(); return jsonify(ok=True)

# ---------- reports ----------
def build_report(kind):
    if kind == "sentiment":
        return "Customer Sentiment Report", ["Product", "Reviews", "Avg Rating", "Positive %", "Negative %", "Neutral %", "Mixed %"], \
            [[p["name"], p["total"], p["avg_rating"], p["pct"]["Positive"], p["pct"]["Negative"], p["pct"]["Neutral"], p["pct"]["Mixed"]] for p in (pstats(x["id"]) for x in rows("SELECT id FROM products"))]
    if kind == "aspect":
        r = []
        for p in (pstats(x["id"]) for x in rows("SELECT id FROM products")):
            r += [[p["name"], a["aspect"], a["mentions"], a["positive_pct"], a["negative_pct"]] for a in p["aspects"]]
        return "Aspect Analysis Report", ["Product", "Aspect", "Mentions", "Positive %", "Negative %"], r
    if kind == "recurring":
        return "Recurring Complaint Report", ["Product", "Aspect", "Mentions", "Negative %", "Status"], \
            [[i["product"], i["aspect"], i["mentions"], i["negative_pct"], i["status"]] for i in rows("""SELECT p.name product, s.name aspect, i.mentions, i.negative_pct, i.status
             FROM issues i JOIN products p ON p.id=i.product_id JOIN aspects s ON s.id=i.aspect_id ORDER BY i.mentions DESC""")]
    if kind == "comparison":
        a, b = pstats(request.args.get("a")), pstats(request.args.get("b"))
        if not a or not b: return None
        A, B = {x["aspect"]: x for x in a["aspects"]}, {x["aspect"]: x for x in b["aspects"]}
        return f"Product Comparison: {a['name']} vs {b['name']}", ["Aspect", a["name"] + " Pos %", b["name"] + " Pos %", a["name"] + " Neg %", b["name"] + " Neg %"], \
            [[k, A.get(k, {}).get("positive_pct", "-"), B.get(k, {}).get("positive_pct", "-"), A.get(k, {}).get("negative_pct", "-"), B.get(k, {}).get("negative_pct", "-")] for k in sorted(set(A) | set(B))]
    ps = [pstats(x["id"]) for x in rows("SELECT id FROM products")]
    return "Product Opinion Report", ["Product", "Reviews", "Summary"], [[p["name"], p["total"], p["summary"]] for p in ps]

@app.get("/api/reports/<kind>")
@auth("analyst", "product_manager")
def report(kind):
    r = build_report(kind)
    if not r: return err("Select two products for comparison")
    t, cols, data = r
    if request.args.get("format") == "csv":
        o = io.StringIO(); w = csv.writer(o); w.writerow(cols); w.writerows(data)
        return Response(o.getvalue(), mimetype="text/csv", headers={"Content-Disposition": f"attachment; filename={kind}_report.csv"})
    return jsonify(title=t, columns=cols, rows=data)

# ---------- users ----------
@app.get("/api/users")
@auth()
def users():
    if g.user["role"] != "admin": return err("Forbidden", 403)
    return jsonify(rows("SELECT id,name,email,role,created_at FROM users"))
@app.post("/api/users")
@auth()
def user_add():
    d = request.json or {}
    if g.user["role"] != "admin": return err("Forbidden", 403)
    if d.get("role") not in ROLES or not d.get("email") or not d.get("name") or not d.get("password"): return err("name, email, password, valid role required")
    if one("SELECT 1 FROM users WHERE email=?", (d["email"].lower(),)): return err("Email exists")
    db().execute("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)", (d["name"], d["email"].lower(), generate_password_hash(d["password"]), d["role"]))
    db().commit(); return jsonify(ok=True), 201
@app.put("/api/users/<int:uid>")
@auth()
def user_edit(uid):
    d = request.json or {}
    if g.user["role"] != "admin" or d.get("role") not in ROLES: return err("Forbidden or invalid role", 403)
    db().execute("UPDATE users SET role=? WHERE id=?", (d["role"], uid)); db().commit(); return jsonify(ok=True)
@app.delete("/api/users/<int:uid>")
@auth()
def user_del(uid):
    if g.user["role"] != "admin" or uid == g.user["id"]: return err("Forbidden", 403)
    try: db().execute("DELETE FROM users WHERE id=?", (uid,)); db().commit()
    except Exception: return err("User has reviews and cannot be deleted")
    return jsonify(ok=True)

# ---------- ITPM ----------
def load_itpm(): return json.loads(ITPM.read_text())
def tok(email, pw):
    return app.test_client().post("/api/auth/login", json={"email": email, "password": pw})
def run_tests():
    c = app.test_client(); T = lambda e, p: {"Authorization": "Bearer " + tok(e, p).json["token"]}
    asp = lambda t: {o["aspect"]: o["sentiment"] for o in analyze_review(t)["opinions"]}
    cases = [
     ("TC01", "Authentication", "manager@hometech.com / valid password", "HTTP 200 + token", lambda: (str(tok("manager@hometech.com", "Manager@123").status_code), lambda a: a == "200")),
     ("TC02", "Authentication", "valid email / wrong password", "HTTP 401", lambda: (str(tok("manager@hometech.com", "bad").status_code), lambda a: a == "401")),
     ("TC03", "RBAC", "Customer opens /api/dashboard", "HTTP 403", lambda: (str(c.get("/api/dashboard", headers=T("customer@hometech.com", "Customer@123")).status_code), lambda a: a == "403")),
     ("TC04", "RBAC", "Customer POST /api/products", "HTTP 403", lambda: (str(c.post("/api/products", json={}, headers=T("customer@hometech.com", "Customer@123")).status_code), lambda a: a == "403")),
     ("TC05", "Sentiment", "Excellent cooling ... but compressor is noisy", "Mixed", lambda: (analyze_review("The refrigerator has excellent cooling and looks beautiful, but it consumes too much electricity and the compressor is noisy.")["overall_sentiment"], lambda a: a == "Mixed")),
     ("TC06", "Aspect extraction", "Washer cleans well but a lot of noise", "Washing Quality +, Noise -", lambda: (str(asp("The washing machine cleans clothes very well but makes a lot of noise during spinning.")), lambda a: "'Washing Quality': 'Positive'" in a and "'Noise': 'Negative'" in a)),
     ("TC07", "Negation", "The vacuum is not noisy at all", "Noise Positive", lambda: (str(asp("The vacuum is not noisy at all.")), lambda a: "'Noise': 'Positive'" in a)),
     ("TC08", "Neutral detection", "Arrived on time. Does the job as expected.", "Neutral", lambda: (analyze_review("Arrived on time. Does the job as expected.", 3)["overall_sentiment"], lambda a: a == "Neutral")),
     ("TC09", "Classification", "Suction and dust on carpet", "Vacuum Cleaner", lambda: (analyze_review("Great suction, picks up dust from carpet")["predicted_category"], lambda a: a == "Vacuum Cleaner")),
     ("TC10", "Dashboard API", "Manager GET /api/dashboard", "HTTP 200", lambda: (str(c.get("/api/dashboard", headers=T("manager@hometech.com", "Manager@123")).status_code), lambda a: a == "200")),
     ("TC11", "Issue workflow", "Analyst tries to change issue status", "HTTP 403", lambda: (str(c.put("/api/issues/1", json={"status": "Resolved"}, headers=T("analyst@hometech.com", "Analyst@123")).status_code), lambda a: a == "403")),
    ]
    res = []
    for id_, f, i, e, fn in cases:
        try: a, ok = fn(); st = "Passed" if ok(a) else "Failed"
        except Exception as ex: a, st = str(ex)[:80], "Failed"
        res.append({"id": id_, "feature": f, "input": i, "expected": e, "actual": a, "status": st})
    d = load_itpm(); d["tests"] = res; ITPM.write_text(json.dumps(d, indent=1)); return res

@app.get("/api/itpm")
@auth("product_manager")
def itpm():
    d = load_itpm()
    if not d["tests"]: d["tests"] = run_tests()
    return jsonify(d)
@app.post("/api/itpm/tests/run")
@auth("product_manager")
def itpm_tests(): return jsonify(run_tests())
@app.put("/api/itpm/tasks/<int:tid>")
@auth("product_manager")
def itpm_task(tid):
    d = load_itpm(); b = request.json or {}
    for t in d["tasks"]:
        if t["id"] == tid:
            if b.get("status") in ("Not Started", "In Progress", "Completed", "Blocked"): t["status"] = b["status"]
            if isinstance(b.get("pct"), int): t["pct"] = max(0, min(100, b["pct"]))
    ITPM.write_text(json.dumps(d, indent=1)); return jsonify(ok=True)

if __name__ == "__main__":
    app.run(port=5000, debug=False)

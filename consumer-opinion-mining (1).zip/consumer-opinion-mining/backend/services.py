import sqlite3, pathlib
ROOT = pathlib.Path(__file__).resolve().parents[1]
DB = ROOT / "database" / "hometech.db"

def connect():
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON"); return c

def init_db():
    if DB.exists(): DB.unlink()
    c = connect(); c.executescript((ROOT / "database" / "schema.sql").read_text())
    import seed; seed.run(c); c.commit(); c.close()

def aspect_id(c, name):
    c.execute("INSERT OR IGNORE INTO aspects(name) VALUES(?)", (name,))
    return c.execute("SELECT id FROM aspects WHERE name=?", (name,)).fetchone()[0]

def save_analysis(c, rid, res):
    c.execute("DELETE FROM opinions WHERE review_id=?", (rid,))
    c.execute("DELETE FROM review_analysis WHERE review_id=?", (rid,))
    c.execute("INSERT INTO review_analysis(review_id,overall_sentiment,sentiment_score,keywords,predicted_category,cleaned_text) VALUES(?,?,?,?,?,?)",
              (rid, res["overall_sentiment"], res["sentiment_score"], ",".join(res["keywords"]), res["predicted_category"], res["cleaned_text"]))
    for o in res["opinions"]:
        c.execute("INSERT INTO opinions(review_id,aspect_id,opinion_text,sentiment,score) VALUES(?,?,?,?,?)",
                  (rid, aspect_id(c, o["aspect"]), o["opinion"], o["sentiment"], o["score"]))
    c.execute("UPDATE reviews SET processing_status='analyzed' WHERE id=?", (rid,))

def detect_issues(c, min_neg=3, min_pct=40):
    rows = c.execute("""SELECT r.product_id pid, o.aspect_id aid, COUNT(*) n, SUM(o.sentiment='Negative') neg
        FROM opinions o JOIN reviews r ON r.id=o.review_id GROUP BY 1,2""").fetchall()
    for r in rows:
        pct = round(100.0 * r["neg"] / r["n"])
        if r["neg"] >= min_neg and pct >= min_pct:
            c.execute("""INSERT INTO issues(product_id,aspect_id,mentions,negative_pct) VALUES(?,?,?,?)
                ON CONFLICT(product_id,aspect_id) DO UPDATE SET mentions=excluded.mentions,
                negative_pct=excluded.negative_pct, updated_at=CURRENT_TIMESTAMP""", (r["pid"], r["aid"], r["neg"], pct))

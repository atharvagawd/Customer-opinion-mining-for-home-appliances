import random, datetime, sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from werkzeug.security import generate_password_hash
from asma.engine import analyze_review
import services as S

PRODUCTS = [
 ("Samsung Refrigerator","Samsung","Refrigerator","RT42","54990","Double-door frost-free inverter refrigerator, 465L"),
 ("LG Refrigerator","LG","Refrigerator","GL-340","49990","Smart inverter double-door refrigerator, 420L"),
 ("LG Washing Machine","LG","Washing Machine","FHM1408","38990","8 kg front-load washing machine with steam"),
 ("Bosch Washing Machine","Bosch","Washing Machine","WAJ2846","42990","7.5 kg front-load, anti-vibration design"),
 ("Daikin Air Conditioner","Daikin","Air Conditioner","FTKM50","45990","1.5 ton 5-star inverter split AC"),
 ("Voltas Air Conditioner","Voltas","Air Conditioner","185V","35990","1.5 ton 3-star inverter split AC"),
 ("IFB Microwave Oven","IFB","Microwave Oven","30SC4","14990","30L convection microwave oven"),
 ("Samsung Microwave Oven","Samsung","Microwave Oven","MC28","16990","28L convection microwave with ceramic enamel"),
 ("Dyson Vacuum Cleaner","Dyson","Vacuum Cleaner","V11","52900","Cordless stick vacuum cleaner"),
 ("Eureka Forbes Vacuum Cleaner","Eureka Forbes","Vacuum Cleaner","Vortex","7990","Bagless canister vacuum cleaner"),
]
USERS = [("Admin User","admin@hometech.com","Admin@123","admin"),("Meera Joshi","manager@hometech.com","Manager@123","product_manager"),
 ("Arjun Rao","analyst@hometech.com","Analyst@123","analyst"),("Riya Sharma","customer@hometech.com","Customer@123","customer")] + \
 [(n, n.split()[0].lower()+"@mail.com","Customer@123","customer") for n in
  ["Vikram Singh","Anita Desai","Rahul Verma","Pooja Patil","Sanjay Gupta","Neha Kapoor","Amit Kulkarni","Divya Menon"]]

POOL = {
 "Refrigerator": {"noun":"refrigerator",
  "pos":["the cooling is excellent","it looks beautiful in our kitchen","the freezer works great","customer service was very helpful","installation was quick and easy","the finish is sleek and premium","it is very quiet"],
  "neg":{"energy":["it consumes too much electricity","we see a high electricity bill since buying it","it consumes too much energy"],
         "noise":["the compressor is very noisy at night","there is a loud humming sound from the back","it makes a lot of noise when the compressor starts"],
         "cooling":["the cooling is poor in summer","the freezer is weak and ice cream melts","cooling is slow after opening the door"],
         "service":["the customer support was rude and unhelpful","customer service was poor and never called back","the technician was rude"],
         "dur":["the door broke within six months","the shelf broke after a few months","the handle feels flimsy"],
         "price":["it is overpriced for the brand","it is expensive compared to similar models"]}},
 "Washing Machine": {"noun":"washer",
  "pos":["it cleans clothes very well","the design is sleek and stylish","great features and smart modes","the washing quality is excellent","the technician was friendly and prompt","it removes stains very well","the spin cycle is quiet"],
  "neg":{"noise":["it makes a lot of noise during spinning","the drum is very loud while spinning","it is noisy during the spin cycle"],
         "vib":["the machine vibrates badly","there is a lot of vibration and it shakes the floor","the machine wobbles during heavy loads"],
         "inst":["installation was delayed by two weeks","the installation delay was frustrating","the technician never showed up for installation"],
         "service":["customer support was unhelpful","customer care was rude","the service staff was slow to respond"],
         "dur":["the drum broke after eight months","the door lock stopped working","the build quality is flimsy"],
         "price":["it is overpriced","it is expensive for this capacity"]}},
 "Air Conditioner": {"noun":"air conditioner",
  "pos":["the cooling is excellent and fast","it is very quiet","it is energy efficient","the design is sleek","good value for money","the technician was helpful","the room cools very well"],
  "neg":{"inst":["installation was delayed for a week","installation took forever and was badly delayed"],
         "energy":["we get a high electricity bill every month","it consumes too much electricity","the high electricity usage is a problem"],
         "remote":["the remote is unresponsive","the remote is faulty"],
         "service":["the technician was rude","customer support was unhelpful"],
         "cooling":["the cooling is weak in peak summer","the cooling is slow"],
         "dur":["the unit stopped working after four months","the outdoor unit broke within a year"]}},
 "Microwave Oven": {"noun":"microwave oven",
  "pos":["the performance is excellent","the display is easy to use","sleek design","good value for money","the customer service was helpful","the build quality is durable"],
  "neg":{"noise":["the turntable is noisy","it is loud while running"],
         "dur":["the build quality feels flimsy","the door broke after a few months"],
         "price":["it is overpriced","it is expensive for a convection model"],
         "service":["customer support was poor","the service centre was unhelpful"],
         "feat":["the timer is faulty","the display is difficult to read"],
         "inst":["delivery was delayed","delivery was delayed by a week"]}},
 "Vacuum Cleaner": {"noun":"vacuum cleaner",
  "pos":["the suction is powerful","the filter is easy to clean","the design is sleek","great value for money","customer care was friendly","it works great on carpets"],
  "neg":{"noise":["it is very loud","the motor is noisy"],
         "maint":["the filter is difficult to maintain","filter cleaning is cumbersome"],
         "dur":["it stopped working after three months","the hose broke within weeks"],
         "price":["it is overpriced","it is expensive for what it offers"],
         "service":["customer care was unresponsive","customer support was rude"],
         "perf":["the suction is weak","the suction is poor on carpets"]}},
}
CHRONIC = {0:["energy","noise"],1:["noise","cooling"],2:["noise","vib","inst"],3:["service","price"],4:["inst","service"],
           5:["energy","dur"],6:["dur","feat"],7:["price","service"],8:["price","dur"],9:["noise","service"]}
NEUTRAL = ["I bought this {n} last month. It arrived on time.","Average {n}. Does the job as expected.","Received the {n} yesterday and am still testing it.",
           "Using this {n} for two weeks now. No strong feelings so far.","Standard {n}, not much to say yet.","Just unboxed the {n}. Will update after a month of use."]
OPEN = ["After two months of use, ","Using it daily for a few weeks, ","We bought this for our new flat. ","Ordered online last month. ","Purchased during the festive sale. "]
CLOSE = [" Using it for a family of four."," Bought it in the monsoon."," Our second purchase from HomeTech."]
cap = lambda s: s[0].upper() + s[1:]

def make(rnd, cat, idx):
    P = POOL[cat]; negs = P["neg"]; ck = CHRONIC[idx]
    pick_neg = lambda: rnd.choice(negs[rnd.choice(ck) if rnd.random() < .7 else rnd.choice(list(negs))])
    t = rnd.random()
    if t < .28:
        a, b = rnd.sample(P["pos"], 2); body = rnd.choice([f"{cap(a)}. {cap(b)}.", f"{cap(a)} and {b}.", f"{cap(a)}, {b}."]); rating = rnd.randint(4, 5)
    elif t < .50:
        a, b = pick_neg(), pick_neg()
        body = f"{cap(a)}. {cap(b)}." if a != b and rnd.random() < .5 else f"{cap(a)}."; rating = rnd.randint(1, 2)
    elif t < .84:
        p, n = rnd.choice(P["pos"]), pick_neg()
        body = rnd.choice([f"{cap(p)}, but {n}.", f"{cap(p)}. However, {n}.", f"Although {n}, {p}.", f"{cap(p)}, but {n}. {cap(rnd.choice(P['pos']))}."]); rating = rnd.choice([2, 3, 3, 4])
    else:
        return rnd.choice(NEUTRAL).format(n=P["noun"]), 3
    if rnd.random() < .35:
        o = rnd.choice(OPEN); body = o + (body[0].lower() + body[1:] if o.endswith(", ") else body)
    if rnd.random() < .2 and t >= .28: body += rnd.choice(CLOSE)
    return body, rating

def run(c):
    rnd = random.Random(7)
    for n, e, pw, role in [(u[0], u[1], u[2], u[3]) for u in USERS]:
        c.execute("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)", (n, e, generate_password_hash(pw), role))
    for p in PRODUCTS:
        c.execute("INSERT INTO products(name,brand,category,model,price,description) VALUES(?,?,?,?,?,?)", p)
    customers = [r[0] for r in c.execute("SELECT id FROM users WHERE role='customer'")]
    now = datetime.datetime.now()
    for idx, p in enumerate(PRODUCTS):
        for _ in range(11):
            text, rating = make(rnd, p[2], idx)
            ts = (now - datetime.timedelta(days=rnd.randint(0, 89), hours=rnd.randint(0, 23))).strftime("%Y-%m-%d %H:%M:%S")
            cur = c.execute("INSERT INTO reviews(user_id,product_id,review_text,rating,created_at) VALUES(?,?,?,?,?)",
                            (rnd.choice(customers), idx + 1, text, rating, ts))
            S.save_analysis(c, cur.lastrowid, analyze_review(text, rating))
    S.detect_issues(c)
    top = c.execute("SELECT id FROM issues ORDER BY mentions DESC").fetchall()
    pm = c.execute("SELECT id FROM users WHERE role='product_manager'").fetchone()[0]
    for i, st, note in [(0, "Under Review", "Escalated to engineering for investigation."), (1, "In Progress", "Supplier contacted; fix in testing."),
                        (2, "Resolved", "Firmware/process fix verified.")]:
        if i < len(top):
            c.execute("UPDATE issues SET status=?, assigned_to=? WHERE id=?", (st, pm, top[i][0]))
            c.execute("INSERT INTO issue_updates(issue_id,user_id,old_status,new_status,note) VALUES(?,?,?,?,?)", (top[i][0], pm, "New", st, note))

if __name__ == "__main__":
    S.init_db(); print("Database seeded.")
